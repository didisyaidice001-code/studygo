package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.screens.*
import com.example.ui.theme.StudyBuddyTheme
import com.example.ui.viewmodel.StudyViewModel
import com.example.ui.viewmodel.PomodoroNotificationState
import androidx.compose.ui.draw.scale
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.RepeatMode

class MainActivity : ComponentActivity() {

    private val viewModel: StudyViewModel by viewModels()

    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            StudyBuddyTheme {
                var currentScreen by remember { mutableStateOf("splash") }
                var currentTab by remember { mutableStateOf("home") }
                var showAddTaskDialog by remember { mutableStateOf(false) }

                // Retrieve toast trigger from ViewModel
                val toastMessage by viewModel.successToast.collectAsState()

                // Retrieve custom pomodoro notification from ViewModel
                val pNotification by viewModel.pomodoroNotification.collectAsState()

                val context = androidx.compose.ui.platform.LocalContext.current
                var hasPostNotificationPermission by remember {
                    mutableStateOf(
                        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
                            androidx.core.content.ContextCompat.checkSelfPermission(
                                context,
                                android.Manifest.permission.POST_NOTIFICATIONS
                            ) == android.content.pm.PackageManager.PERMISSION_GRANTED
                        } else {
                            true
                        }
                    )
                }

                val permissionLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
                    contract = androidx.activity.result.contract.ActivityResultContracts.RequestPermission()
                ) { isGranted ->
                    hasPostNotificationPermission = isGranted
                }

                // Check and auto-request permission when entering relevant screen
                LaunchedEffect(currentScreen) {
                    if (currentScreen == "recharge") {
                        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU && !hasPostNotificationPermission) {
                            permissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
                        }
                    }
                }

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    topBar = {
                        if (currentScreen == "main") {
                            StudyTopAppBar(
                                title = "StudyGo",
                                onSearchClick = { currentTab = "explore" },
                                onNotificationsClick = { currentScreen = "notifications" },
                                onMenuClick = { viewModel.triggerToast("StudyGo v1.0.0 par Felix & Alex") }
                            )
                        }
                    },
                    bottomBar = {
                        if (currentScreen == "main") {
                            StudyBottomBar(
                                currentTab = currentTab,
                                onTabSelected = { currentTab = it }
                            )
                        }
                    },
                    containerColor = MaterialTheme.colorScheme.background
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(
                                top = if (currentScreen == "main") innerPadding.calculateTopPadding() else 0.dp,
                                bottom = if (currentScreen == "main") innerPadding.calculateBottomPadding() else 0.dp
                            )
                    ) {
                        // Animated Screen Router with slow upward slide (600ms)
                        AnimatedContent(
                            targetState = currentScreen,
                            transitionSpec = {
                                slideInVertically(
                                    animationSpec = tween(600, easing = FastOutSlowInEasing),
                                    initialOffsetY = { it }
                                ) + fadeIn(animationSpec = tween(600)) togetherWith
                                        slideOutVertically(
                                            animationSpec = tween(600, easing = FastOutSlowInEasing),
                                            targetOffsetY = { -it }
                                        ) + fadeOut(animationSpec = tween(600))
                            },
                            label = "screenRouter"
                        ) { screen ->
                            when (screen) {
                                "splash" -> {
                                    SplashScreen(onSplashComplete = { currentScreen = "onboarding" })
                                }
                                "onboarding" -> {
                                    OnboardingScreen(onComplete = { currentScreen = "login" })
                                }
                                "login" -> {
                                    LoginScreen(onLoginClick = { currentScreen = "main" })
                                }
                                "main" -> {
                                    AnimatedContent(
                                        targetState = currentTab,
                                        transitionSpec = {
                                            slideInVertically(
                                                animationSpec = tween(600, easing = FastOutSlowInEasing),
                                                initialOffsetY = { it }
                                            ) + fadeIn(animationSpec = tween(600)) togetherWith
                                                    slideOutVertically(
                                                        animationSpec = tween(600, easing = FastOutSlowInEasing),
                                                        targetOffsetY = { -it }
                                                    ) + fadeOut(animationSpec = tween(600))
                                        },
                                        label = "innerTabsTransition"
                                    ) { tabState ->
                                        when (tabState) {
                                            "home" -> {
                                                DashboardScreen(
                                                    viewModel = viewModel,
                                                    onTabSelected = { currentTab = it },
                                                    onSubjectClick = { subject ->
                                                         val normSub = when (subject) {
                                                             "Advanced Calculus", "Mathematics", "AdvancedCalculus" -> "Mathématiques"
                                                             "Macroeconomics", "Economy", "MacroEconomics" -> "Économie"
                                                             "World History", "History", "WorldHistory" -> "Histoire & Géographie"
                                                             else -> subject
                                                         }
                                                         viewModel.selectedSubject.value = normSub
                                                         currentScreen = "subject_detail"
                                                     },
                                                    onLaunchPomodoro = {
                                                        viewModel.resetTimer(1500) // 25 Min Pomodoro
                                                        currentScreen = "recharge"
                                                        viewModel.startTimer()
                                                    }
                                                )
                                            }
                                            "explore" -> {
                                                ExploreScreen(
                                                    viewModel = viewModel
                                                )
                                            }
                                            "planner" -> {
                                                PlannerScreen(
                                                    viewModel = viewModel,
                                                    onAddTaskClick = { showAddTaskDialog = true }
                                                )
                                            }
                                            "progress" -> {
                                                ProgressScreen(
                                                    viewModel = viewModel,
                                                    onVoirBadgesClick = { currentScreen = "milestone" }
                                                )
                                            }
                                            "profile" -> {
                                                ProfileScreen(
                                                    viewModel = viewModel,
                                                    onTabSelected = { currentTab = it },
                                                    onLeaderboardClick = { currentScreen = "leaderboard" }
                                                )
                                            }
                                        }
                                    }
                                }
                                "subject_detail" -> {
                                    SubjectDetailScreen(
                                        viewModel = viewModel,
                                        onBack = { currentScreen = "main" },
                                        onStartQuiz = {
                                            viewModel.optionSelected.value = null
                                            currentScreen = "quiz"
                                        }
                                    )
                                }
                                "quiz" -> {
                                    QuizScreen(
                                        viewModel = viewModel,
                                        onBack = { currentScreen = "subject_detail" },
                                        onQuizComplete = { currentScreen = "milestone" }
                                    )
                                }
                                "milestone" -> {
                                    MilestoneScreen(
                                        viewModel = viewModel,
                                        onBackToPlanner = {
                                            currentTab = "planner"
                                            currentScreen = "main"
                                        }
                                    )
                                }
                                "recharge" -> {
                                    RechargeBreakScreen(
                                        viewModel = viewModel,
                                        onSkipBreak = {
                                            viewModel.skipBreak()
                                            currentScreen = "main"
                                        }
                                    )
                                }
                                "leaderboard" -> {
                                    LeaderboardScreen(
                                        onBack = { currentScreen = "main" }
                                    )
                                }
                                "notifications" -> {
                                    NotificationsScreen(
                                        onBack = { currentScreen = "main" }
                                    )
                                }
                            }
                        }

                        // Premium Animated Floating Toast HUD
                        AnimatedVisibility(
                            visible = toastMessage != null,
                            enter = slideInVertically(initialOffsetY = { -it }) + fadeIn(),
                            exit = slideOutVertically(targetOffsetY = { -it }) + fadeOut(),
                            modifier = Modifier
                                .align(Alignment.TopCenter)
                                .padding(top = 24.dp)
                        ) {
                            toastMessage?.let { msg ->
                                Card(
                                    shape = RoundedCornerShape(99.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondary),
                                    elevation = CardDefaults.cardElevation(8.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Check,
                                            contentDescription = "Success",
                                            tint = Color.White
                                        )
                                        Text(
                                            text = msg,
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            style = MaterialTheme.typography.bodyMedium
                                        )
                                    }
                                }
                            }
                        }

                        // Personalized Custom Animated Notification Banner
                        AnimatedVisibility(
                            visible = pNotification != null,
                            enter = slideInVertically(initialOffsetY = { -it }) + fadeIn() + expandVertically(),
                            exit = slideOutVertically(targetOffsetY = { -it }) + fadeOut() + shrinkVertically(),
                            modifier = Modifier
                                .align(Alignment.TopCenter)
                                .padding(top = 90.dp)
                                .fillMaxWidth()
                        ) {
                            pNotification?.let { notif ->
                                PomodoroCustomNotificationBanner(
                                    notification = notif,
                                    onDismiss = { viewModel.dismissNotification() },
                                    onActionClick = {
                                        viewModel.dismissNotification()
                                        if (notif.isBreak) {
                                            currentScreen = "recharge"
                                            viewModel.startTimer()
                                        } else {
                                            currentScreen = "main"
                                            currentTab = "home"
                                        }
                                    }
                                )
                            }
                        }

                        // Bottom-Sheet ADD TASK Dialog Form (Highly Interactive!)
                        if (showAddTaskDialog) {
                            var title by remember { mutableStateOf("") }
                            var subject by remember { mutableStateOf("Mathématiques") }
                            var priority by remember { mutableStateOf("Moyen") } // "Élevé", "Moyen", "Faible"

                            AlertDialog(
                                onDismissRequest = { showAddTaskDialog = false },
                                title = {
                                    Text(
                                        "Nouvelle Tâche d'Étude",
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                },
                                text = {
                                    Column(
                                        verticalArrangement = Arrangement.spacedBy(16.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        TextField(
                                            value = title,
                                            onValueChange = { title = it },
                                            label = { Text("Titre de la tâche") },
                                            modifier = Modifier.fillMaxWidth(),
                                            singleLine = true
                                        )

                                        // Beautiful selected date highlight
                                        val sdf = remember { java.text.SimpleDateFormat("EEEE d MMMM yyyy", java.util.Locale.FRANCE) }
                                        val dateStr = sdf.format(java.util.Date(viewModel.selectedCalendarDate.value))
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .background(MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                                                .padding(12.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.EventNote,
                                                contentDescription = null,
                                                tint = MaterialTheme.colorScheme.secondary
                                            )
                                            Column {
                                                Text(
                                                    text = "Échéance de la tâche",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.outline
                                                )
                                                Text(
                                                    text = dateStr.replaceFirstChar { if (it.isLowerCase()) it.titlecase(java.util.Locale.FRANCE) else it.toString() },
                                                    style = MaterialTheme.typography.bodyMedium,
                                                    fontWeight = FontWeight.Bold,
                                                    color = MaterialTheme.colorScheme.onSecondaryContainer
                                                )
                                            }
                                        }

                                        // Subject Select option row chips
                                        Column {
                                            Text(
                                                "Matière",
                                                style = MaterialTheme.typography.labelMedium,
                                                fontWeight = FontWeight.Bold
                                            )
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Row(
                                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                                            ) {
                                                listOf("Mathématiques", "Sciences Physiques", "Histoire & Géographie", "Économie", "Littérature").forEach { sub ->
                                                    val isSelected = subject == sub
                                                    Box(
                                                        modifier = Modifier
                                                            .clip(RoundedCornerShape(99.dp))
                                                            .background(
                                                                if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceContainer
                                                            )
                                                            .clickable { subject = sub }
                                                            .padding(horizontal = 12.dp, vertical = 6.dp)
                                                    ) {
                                                        Text(
                                                            sub,
                                                            color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                                            fontSize = 11.sp,
                                                            fontWeight = FontWeight.Bold
                                                        )
                                                    }
                                                }
                                            }
                                        }

                                        // Priority selectors
                                        Column {
                                            Text(
                                                "Priorité",
                                                style = MaterialTheme.typography.labelMedium,
                                                fontWeight = FontWeight.Bold
                                            )
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Row(
                                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                                            ) {
                                                listOf("Élevé", "Moyen", "Faible").forEach { prio ->
                                                    val isSelected = priority == prio
                                                    Box(
                                                        modifier = Modifier
                                                            .clip(RoundedCornerShape(99.dp))
                                                            .background(
                                                                if (isSelected) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.surfaceContainer
                                                            )
                                                            .clickable { priority = prio }
                                                            .padding(horizontal = 12.dp, vertical = 6.dp)
                                                    ) {
                                                        Text(
                                                            prio,
                                                            color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                                            fontSize = 11.sp,
                                                            fontWeight = FontWeight.Bold
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }
                                },
                                confirmButton = {
                                    Button(
                                        onClick = {
                                            if (title.isNotBlank()) {
                                                viewModel.addTask(title, subject, priority, viewModel.selectedCalendarDate.value)
                                                showAddTaskDialog = false
                                            } else {
                                                viewModel.triggerToast("Veuillez saisir un titre !")
                                            }
                                        }
                                    ) {
                                        Text("Ajouter")
                                    }
                                },
                                dismissButton = {
                                    TextButton(onClick = { showAddTaskDialog = false }) {
                                        Text("Annuler")
                                    }
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

// Global Notification Feed Screen
@Composable
fun NotificationsScreen(
    onBack: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(bottom = 32.dp)
    ) {
        item {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.padding(top = 16.dp)
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Retour")
                }
                Text(
                    text = "Notifications",
                    style = MaterialTheme.typography.headlineLarge,
                    color = MaterialTheme.colorScheme.onSurface,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        itemsIndexed(
            listOf(
                NotificationItem("Badge débloqué !", "Félicitations, vous avez débloqué le badge 'Lève-tôt' !", Icons.Default.MilitaryTech, true),
                NotificationItem("Défi hebdomadaire", "Le défi d'étude de mathématiques de 5 heures commence maintenant.", Icons.Default.School, false),
                NotificationItem("Session Pomodoro terminée", "Félicitations pour avoir complété votre session d'étude !", Icons.Default.CheckCircle, false)
            )
        ) { index, item ->
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (item.isNew) MaterialTheme.colorScheme.primary.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceContainerLowest
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        1.dp,
                        MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f),
                        RoundedCornerShape(16.dp)
                    )
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .background(MaterialTheme.colorScheme.surfaceVariant, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = item.icon,
                            tint = MaterialTheme.colorScheme.primary,
                            contentDescription = null
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            item.title,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            item.body,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

data class NotificationItem(
    val title: String,
    val body: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val isNew: Boolean
)

@Composable
fun PomodoroCustomNotificationBanner(
    notification: PomodoroNotificationState,
    onDismiss: () -> Unit,
    onActionClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulseHalo")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.98f)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 12.dp),
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .border(
                width = 2.dp,
                brush = androidx.compose.ui.graphics.Brush.horizontalGradient(
                    colors = if (notification.isBreak) {
                        listOf(Color(0xFFFF5252), Color(0xFFFF7A00))
                    } else {
                        listOf(Color(0xFF2196F3), Color(0xFF00E676))
                    }
                ),
                shape = RoundedCornerShape(24.dp)
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Animated Pulsing Circle
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .scale(pulseScale)
                        .background(
                            if (notification.isBreak) Color(0xFFFFECEB) else Color(0xFFE3F2FD),
                            CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .background(
                                if (notification.isBreak) Color(0xFFFF5252) else Color(0xFF2196F3),
                                CircleShape
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (notification.isBreak) Icons.Default.Timer else Icons.Default.Star,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = notification.title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Black,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = notification.body,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                    )
                }

                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier.align(Alignment.Top)
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Fermer",
                        tint = MaterialTheme.colorScheme.outline
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Action CTA button inside the custom notification card
            Button(
                onClick = onActionClick,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (notification.isBreak) Color(0xFFFF5252) else Color(0xFF2196F3)
                ),
                shape = RoundedCornerShape(99.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(44.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center,
                    modifier = Modifier.fillMaxSize()
                ) {
                    Text(
                        text = if (notification.isBreak) "Take a Break / Faire une pause" else "Back to Work / Reprendre l'étude",
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Icon(
                        imageVector = Icons.Default.ArrowForward,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}
