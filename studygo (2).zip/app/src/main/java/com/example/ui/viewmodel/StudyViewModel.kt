package com.example.ui.viewmodel

import android.app.Application
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.Task
import com.example.data.TaskRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

data class PomodoroNotificationState(
    val title: String,
    val body: String,
    val isBreak: Boolean,
    val timestamp: Long = System.currentTimeMillis()
)

class StudyViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: TaskRepository
    val tasks: MutableStateFlow<List<Task>> = MutableStateFlow(emptyList())

    val selectedSubject = MutableStateFlow("Mathématiques")

    init {
        val database = AppDatabase.getDatabase(application)
        repository = TaskRepository(database.taskDao())

        // Observe Room DB reactively and pre-populate if empty to offer rich initial content!
        viewModelScope.launch {
            repository.allTasks.collectLatest { taskList ->
                if (taskList.isEmpty()) {
                    val now = System.currentTimeMillis()
                    val oneDay = 86400000L
                    val initialTasks = listOf(
                        Task(title = "DM3 : Dérivabilité et théorème des valeurs intermédiaires", subject = "Mathématiques", priority = "Élevé", timestamp = now),
                        Task(title = "Compte-rendu : TP1 Diffraction de la lumière et lentilles convergentes", subject = "Sciences Physiques", priority = "Élevé", timestamp = now + oneDay),
                        Task(title = "Fiche de lecture : Le siècle de Périclès et l'Athènes démocratique", subject = "Histoire & Géographie", priority = "Moyen", timestamp = now + oneDay * 2),
                        Task(title = "Dissertation de Français : Analyse comparée du réalisme chez Balzac", subject = "Littérature", priority = "Élevé", timestamp = now + oneDay * 3),
                        Task(title = "Exposé oral : Comparaison du modèle Keynesien vs Monétariste", subject = "Économie", priority = "Moyen", timestamp = now),
                        Task(title = "Série d'exercices d'entraînement : Énergie potentielle de pesanteur", subject = "Sciences Physiques", priority = "Faible", timestamp = now + oneDay * 4),
                        Task(title = "DM4 d'Algèbre matricielle : Diagonalisation et valeurs propres", subject = "Mathématiques", priority = "Moyen", timestamp = now + oneDay * 2)
                    )
                    for (t in initialTasks) {
                        repository.insert(t)
                    }
                } else {
                    tasks.value = taskList
                }
            }
        }
    }

    // Interactive Stats (Persisted temporarily or customized)
    private val _totalStudyHours = MutableStateFlow(128)
    val totalStudyHours: StateFlow<Int> = _totalStudyHours.asStateFlow()

    private val _completedCourses = MutableStateFlow(12)
    val completedCourses: StateFlow<Int> = _completedCourses.asStateFlow()

    private val _dayStreak = MutableStateFlow(24)
    val dayStreak: StateFlow<Int> = _dayStreak.asStateFlow()

    // Pomodoro Timer States
    private val _timerSecondsLeft = MutableStateFlow(1500) // 25 Min
    val timerSecondsLeft: StateFlow<Int> = _timerSecondsLeft.asStateFlow()

    private val _timerIsRunning = MutableStateFlow(false)
    val timerIsRunning: StateFlow<Boolean> = _timerIsRunning.asStateFlow()

    private val _timerIsBreakMode = MutableStateFlow(false)
    val timerIsBreakMode: StateFlow<Boolean> = _timerIsBreakMode.asStateFlow()

    private var timerJob: Job? = null

    // Preferences Settings
    val focusAlerts = MutableStateFlow(true)
    val breakReminders = MutableStateFlow(true)
    val goalReminders = MutableStateFlow(true)
    val weeklyReports = MutableStateFlow(false)
    val studyGroupInvites = MutableStateFlow(true)

    // Quiz score
    val quizProgress = MutableStateFlow(5) // Out of 10
    val optionSelected = MutableStateFlow<String?>(null) // "A", "B", "C", "D"

    // Toast triggers
    val successToast = MutableStateFlow<String?>(null)

    // Selected calendar date
    val selectedCalendarDate = MutableStateFlow(System.currentTimeMillis())

    // Pomodoro custom notification state
    val pomodoroNotification = MutableStateFlow<PomodoroNotificationState?>(null)

    fun dismissNotification() {
        pomodoroNotification.value = null
    }

    private fun showLocalNotification(title: String, message: String) {
        val context = getApplication<Application>()
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = "pomodoro_notifications"
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Sessions Pomodoro StudyGo",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Alertes de fin de session Pomodoro et de break"
                enableVibration(true)
            }
            notificationManager.createNotificationChannel(channel)
        }
        
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(context, channelId)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(context)
        }
        
        val systemNotification = builder
            .setContentTitle(title)
            .setContentText(message)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setAutoCancel(true)
            .build()
            
        notificationManager.notify(4002, systemNotification)
    }

    fun triggerNotification(title: String, message: String, isBreak: Boolean) {
        pomodoroNotification.value = PomodoroNotificationState(title, message, isBreak)
        showLocalNotification(title, message)
        triggerToast(title)
    }

    // CRUD Tasks through Repository
    fun addTask(title: String, subject: String, priority: String, timestamp: Long = System.currentTimeMillis()) {
        viewModelScope.launch {
            repository.insert(Task(title = title, subject = subject, priority = priority, timestamp = timestamp))
            triggerToast("Tâche ajoutée avec succès !")
        }
    }

    fun updateTask(task: Task) {
        viewModelScope.launch {
            repository.update(task)
        }
    }

    fun toggleTaskCompletion(task: Task) {
        viewModelScope.launch {
            val updated = task.copy(isCompleted = !task.isCompleted)
            repository.update(updated)
            if (updated.isCompleted) {
                // Increment total study hours slightly as positive reinforcement
                _totalStudyHours.value = _totalStudyHours.value + 1
                triggerToast("Félicitations ! Objectif atteint !")
            }
        }
    }

    fun deleteTask(task: Task) {
        viewModelScope.launch {
            repository.delete(task)
            triggerToast("Tâche supprimée.")
        }
    }

    // Pomodoro Operations
    fun startTimer() {
        if (_timerIsRunning.value) return
        _timerIsRunning.value = true
        timerJob = viewModelScope.launch {
            while (_timerSecondsLeft.value > 0) {
                delay(1000)
                _timerSecondsLeft.value = _timerSecondsLeft.value - 1
            }
            // Finished block!
            _timerIsRunning.value = false
            if (!_timerIsBreakMode.value) {
                // Transition to break
                _timerIsBreakMode.value = true
                _timerSecondsLeft.value = 300 // 5 mins break
                triggerNotification(
                    title = "Session Focus Complétée ! 🍅",
                    message = "Félicitations, vous avez tenu bon. C'est l'heure d'une pause bien méritée de 5 minutes !",
                    isBreak = true
                )
            } else {
                _timerIsBreakMode.value = false
                _timerSecondsLeft.value = 1500
                _totalStudyHours.value = _totalStudyHours.value + 1
                triggerNotification(
                    title = "Pause Session Terminée ! 🚀",
                    message = "La pause est finie. C'est reparti pour focus avec l'esprit serein !",
                    isBreak = false
                )
            }
        }
    }

    fun pauseTimer() {
        _timerIsRunning.value = false
        timerJob?.cancel()
    }

    fun skipBreak() {
        pauseTimer()
        _timerIsBreakMode.value = false
        _timerSecondsLeft.value = 1500 // Return to focus session mins
    }

    fun resetTimer(secs: Int = 1500) {
        pauseTimer()
        _timerIsBreakMode.value = false
        _timerSecondsLeft.value = secs
    }

    fun triggerToast(message: String) {
        successToast.value = message
        viewModelScope.launch {
            delay(3000)
            if (successToast.value == message) {
                successToast.value = null
            }
        }
    }
}
