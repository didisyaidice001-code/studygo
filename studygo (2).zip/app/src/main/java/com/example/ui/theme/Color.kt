package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// StudyGo Official Branding Palettes
val Primary = Color(0xFF3B82F6) // Bleu StudyGo
val OnPrimary = Color(0xFFFFFFFF) // Blanc
val PrimaryContainer = Color(0xFFDBEAFE) // Clair
val OnPrimaryContainer = Color(0xFF1D4ED8)
val InversePrimary = Color(0xFF93C5FD)

val Secondary = Color(0xFF22C55E) // Vert Motivation
val OnSecondary = Color(0xFFFFFFFF)
val SecondaryContainer = Color(0xFFDCFCE7)
val OnSecondaryContainer = Color(0xFF15803D)

val Tertiary = Color(0xFF94A3B8) // Gris moyen
val OnTertiary = Color(0xFFFFFFFF)
val TertiaryContainer = Color(0xFFF1F5F9)
val OnTertiaryContainer = Color(0xFF334155) // Gris foncé

val Background = Color(0xFFF5F7FA) // Gris clair
val OnBackground = Color(0xFF334155) // Gris foncé

val Surface = Color(0xFFF5F7FA) // Gris clair
val OnSurface = Color(0xFF334155) // Gris foncé
val OnSurfaceVariant = Color(0xFF64748B)

val SurfaceDim = Color(0xFFE2E8F0)
val SurfaceBright = Color(0xFFFFFFFF)

val SurfaceContainerLowest = Color(0xFFFFFFFF)
val SurfaceContainerLow = Color(0xFFF8FAFC)
val SurfaceContainer = Color(0xFFF1F5F9)
val SurfaceContainerHigh = Color(0xFFE2E8F0)
val SurfaceContainerHighest = Color(0xFFCBD5E1)

val Outline = Color(0xFF94A3B8)
val OutlineVariant = Color(0xFFCBD5E1)

val Error = Color(0xFFEF4444)
val OnError = Color(0xFFFFFFFF)
val ErrorContainer = Color(0xFFFEE2E2)
val OnErrorContainer = Color(0xFF991B1B)

// Fixed Tonal Colors
val PrimaryFixed = Color(0xFFDBEAFE)
val PrimaryFixedDim = Color(0xFF93C5FD)
val OnPrimaryFixed = Color(0xFF1E3A8A)
val OnPrimaryFixedVariant = Color(0xFF2563EB)

val SecondaryFixed = Color(0xFFDCFCE7)
val SecondaryFixedDim = Color(0xFF86EFAC)
val OnSecondaryFixed = Color(0xFF064E3B)
val OnSecondaryFixedVariant = Color(0xFF16A34A)

val TertiaryFixed = Color(0xFFF1F5F9)
val TertiaryFixedDim = Color(0xFFE2E8F0)
val OnTertiaryFixed = Color(0xFF1E293B)
val OnTertiaryFixedVariant = Color(0xFF475569)
