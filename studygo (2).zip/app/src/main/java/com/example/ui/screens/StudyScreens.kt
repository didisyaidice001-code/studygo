package com.example.ui.screens

import androidx.compose.ui.platform.testTag
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.ui.viewmodel.StudyViewModel
import kotlinx.coroutines.delay
import kotlin.random.Random

// SCREEN 1: Subject Detail (Mathematics Screen)
@Composable
fun SubjectDetailScreen(
    viewModel: StudyViewModel,
    onBack: () -> Unit,
    onStartQuiz: () -> Unit
) {
    val subjectTitle by viewModel.selectedSubject.collectAsState()
    var expandedTopics by remember { mutableStateOf(setOf(1)) }
    var expandAll by remember { mutableStateOf(false) }
    var revisedLessons by remember { mutableStateOf(setOf<String>()) }
    var activeRevisionLesson by remember { mutableStateOf<Pair<String, String>?>(null) } // Title, Content

    val categoryTag = when (subjectTitle) {
        "Sciences Physiques" -> "Sciences & Cosmos"
        "Histoire & Géographie" -> "Histoire & Culture"
        "Économie" -> "Sciences Politiques"
        "Littérature" -> "Lettres & Langues"
        else -> "Sciences & Maths"
    }

    val subtitle = when (subjectTitle) {
        "Sciences Physiques" -> "Explorez les forces invisibles qui régissent l'univers matériel."
        "Histoire & Géographie" -> "Naviguez au cœur du temps pour comprendre les civilisations passées."
        "Économie" -> "Décryptez les mécanismes financiers et administratifs mondiaux."
        "Littérature" -> "Explorez la beauté stylistique et l'art des mots classiques."
        else -> "Maîtrisez les concepts d'Analyse et d'Algèbre de l'Univers moderne."
    }

    val basePercent = when (subjectTitle) {
        "Sciences Physiques" -> 50
        "Histoire & Géographie" -> 30
        "Économie" -> 60
        "Littérature" -> 40
        else -> 75
    }

    val bannerBg = when (subjectTitle) {
        "Sciences Physiques" -> Color(0xFF0284C7)
        "Histoire & Géographie" -> Color(0xFFD97706)
        "Économie" -> Color(0xFF0D9488)
        "Littérature" -> Color(0xFFDB2777)
        else -> Color(0xFF4F46E5)
    }

    val topics = remember(subjectTitle) {
        when (subjectTitle) {
            "Sciences Physiques" -> listOf(
                TopicItem("Optique Géométrique", "Snell-Descartes & Lentilles", true, true, 1f, listOf(
                    LessonItem("Snell-Descartes et prisme optique", "15 mins", true, true),
                    LessonItem("Lentilles convergentes et formation d'images", "20 mins", true, true)
                )),
                TopicItem("Mécanique Classique", "Forces & Lois de Newton", false, true, 0.5f, listOf(
                    LessonItem("Lois de Newton et mécanique d'inertie", "25 mins", true, true),
                    LessonItem("Mouvement de projectiles et gravitation", "30 mins", false, true)
                )),
                TopicItem("Thermodynamique", "Cycles de Carnot et Entropie", false, true, 0f, listOf(
                    LessonItem("Principes fondamentaux de la Thermodynamique", "15 mins", false, true)
                )),
                TopicItem("Chimie Organique", "Liaisons Carbone et Nomenclature", false, true, 0f, listOf(
                    LessonItem("Introduction à la Chimie Organique", "30 mins", false, true)
                ))
            )
            "Histoire & Géographie" -> listOf(
                TopicItem("Antiquité Classique", "Secteur Démocratie d'Athènes", true, true, 1f, listOf(
                    LessonItem("Athènes et le siècle de Périclès", "18 mins", true, true),
                    LessonItem("La République romaine et Jules César", "22 mins", true, true)
                )),
                TopicItem("Moyen-Âge Féodal", "Seigneurs et Châteaux", false, true, 0f, listOf(
                    LessonItem("Moyen-Âge : Châteaux forts et Seigneurs", "20 mins", false, true)
                )),
                TopicItem("Révolutions Industrielles", "Charbon & James Watt", false, true, 0f, listOf(
                    LessonItem("La Révolution Industrielle et le Charbon", "25 mins", false, true)
                )),
                TopicItem("Monde Contemporain", "Conflit de la Guerre Froide", false, true, 0f, listOf(
                    LessonItem("Seconde Guerre Mondiale : Les Tournants", "22 mins", false, true)
                ))
            )
            "Économie" -> listOf(
                TopicItem("Microéconomie", "Loi du Marché concurrentiel", true, true, 1f, listOf(
                    LessonItem("Offre et Demande : Loi du Marché", "15 mins", true, true),
                    LessonItem("Courbes d'utilité et élasticité-prix", "25 mins", true, true)
                )),
                TopicItem("Théories Macro", "Le Modèle IS-LM Keynesien", false, true, 0.5f, listOf(
                    LessonItem("Le Modèle IS-LM Keynesien", "30 mins", true, true)
                )),
                TopicItem("Monnaie & Fiscalité", "Banques et Taux Directeurs", false, true, 0f, listOf(
                    LessonItem("La Monnaie et la Planification Fiscale", "20 mins", false, true)
                )),
                TopicItem("Mondialisation", "Avantage Comparatif de Ricardo", false, true, 0f, listOf(
                    LessonItem("Mondialisation et Accords de Libre Échange", "22 mins", false, true)
                ))
            )
            "Littérature" -> listOf(
                TopicItem("Mouvements Poétiques", "Romantisme & Sensibilité", true, true, 1f, listOf(
                    LessonItem("Le Romantisme chez Victor Hugo", "15 mins", true, true),
                    LessonItem("Le Spleen et l'Idéal baudelairien", "18 mins", true, true)
                )),
                TopicItem("Le Roman Réaliste", "La Comédie Humaine", false, true, 0f, listOf(
                    LessonItem("Le Réalisme d'Honoré de Balzac", "20 mins", false, true)
                )),
                TopicItem("Le Théâtre Moderne", "Bataille d'Hernani", false, true, 0f, listOf(
                    LessonItem("Le Drame Romantique et Théâtre", "22 mins", false, true)
                )),
                TopicItem("Symbolisme Littéraire", "Charles Baudelaire poésies", false, true, 0f, listOf(
                    LessonItem("Baudelaire et le Symbolisme moderne", "20 mins", false, true)
                ))
            )
            else -> listOf(
                TopicItem("Analyse Différentielle", "Dérivabilité & Dérivées", true, true, 1f, listOf(
                    LessonItem("Calcul de Dérivées Usuelles", "18 mins", true, true),
                    LessonItem("Formules de composition et dérivabilité", "20 mins", true, true)
                )),
                TopicItem("Analyse de Riemann", "Continuité & Intégrales", false, true, 0.5f, listOf(
                    LessonItem("Limites et Continuité des fonctions de Riemann", "25 mins", true, true),
                    LessonItem("Calcul de primitives et aires géométriques", "30 mins", false, true)
                )),
                TopicItem("Algèbre Linéaire", "Espaces vectoriels", false, true, 0f, listOf(
                    LessonItem("Exposants & Propriétés de l'exponentielle", "20 mins", false, true)
                )),
                TopicItem("Géométrie Matricielle", "Réduction d'endomorphismes", false, true, 0f, listOf(
                    LessonItem("Diagonalisation et sous-espaces", "22 mins", false, true)
                ))
            )
        }
    }

    val totalLessons = topics.flatMap { it.lessons }.size
    val completedLessons = topics.flatMap { it.lessons }.count { it.isDone || revisedLessons.contains(it.title) }
    val progressPercent = if (totalLessons > 0) (completedLessons * 100) / totalLessons else basePercent

    LaunchedEffect(expandAll) {
        if (expandAll) {
            expandedTopics = setOf(0, 1, 2, 3)
        } else {
            expandedTopics = setOf(1)
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(bottom = 32.dp)
    ) {
        item {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.padding(top = 16.dp)
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Retour")
                }
                Text(
                    text = "Cours & Révisions",
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onSurface,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        item {
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        1.dp,
                        MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f),
                        RoundedCornerShape(24.dp)
                    ),
                elevation = CardDefaults.cardElevation(2.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1.3f)) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(99.dp))
                                    .background(PrimaryFixed)
                                    .padding(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = categoryTag,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = OnPrimaryFixed,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(99.dp))
                                    .background(MaterialTheme.colorScheme.secondaryContainer)
                                    .padding(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = "$progressPercent% Complété",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Text(
                            text = subjectTitle,
                            style = MaterialTheme.typography.headlineLarge,
                            color = MaterialTheme.colorScheme.onSurface,
                            fontWeight = FontWeight.Bold
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = subtitle,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(20.dp))

                        Button(
                            onClick = onStartQuiz,
                            colors = ButtonDefaults.buttonColors(containerColor = bannerBg),
                            shape = RoundedCornerShape(99.dp),
                            modifier = Modifier.fillMaxWidth(),
                            contentPadding = PaddingValues(vertical = 12.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Démarrer le Quiz", fontWeight = FontWeight.Bold, color = Color.White)
                                Spacer(modifier = Modifier.width(6.dp))
                                Icon(Icons.Default.PlayArrow, contentDescription = "Play", tint = Color.White)
                            }
                        }
                    }

                    Box(
                        modifier = Modifier
                            .weight(0.7f)
                            .height(160.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val w = size.width
                            val h = size.height
                            when (subjectTitle) {
                                "Sciences Physiques" -> {
                                    drawCircle(color = Color(0xFF0284C7).copy(alpha = 0.1f), radius = 50f, center = Offset(w/2, h/2))
                                    drawLine(color = Color(0xFF0284C7), start = Offset(w/2 - 30f, h/2 - 30f), end = Offset(w/2 + 30f, h/2 + 30f), strokeWidth = 5f)
                                    drawLine(color = Color(0xFF0284C7), start = Offset(w/2 + 30f, h/2 - 30f), end = Offset(w/2 - 30f, h/2 + 30f), strokeWidth = 5f)
                                    drawCircle(color = Color(0xFFFFB300), radius = 18f, center = Offset(w/2, h/2))
                                    drawCircle(color = Color(0xFF0284C7), radius = 14f, center = Offset(w/2 - 30f, h/2 - 30f))
                                    drawCircle(color = Color(0xFF52C77A), radius = 14f, center = Offset(w/2 + 30f, h/2 + 30f))
                                }
                                "Histoire & Géographie" -> {
                                    drawCircle(color = Color(0xFFD97706).copy(alpha = 0.08f), radius = 55f, center = Offset(w/2, h/2))
                                    drawCircle(color = Color(0xFFD97706), radius = 45f, center = Offset(w/2, h/2), style = Stroke(width = 3f))
                                    drawOval(color = Color(0xFFD97706).copy(alpha = 0.4f), topLeft = Offset(w/2 - 25f, h/2 - 45f), size = androidx.compose.ui.geometry.Size(50f, 90f), style = Stroke(width = 2f))
                                    drawLine(color = Color(0xFFD97706), start = Offset(w/2 - 45f, h/2), end = Offset(w/2 + 45f, h/2), strokeWidth = 2f)
                                }
                                "Économie" -> {
                                    drawOval(color = Color(0xFF0D9488).copy(alpha = 0.08f), topLeft = Offset(10f, 90f), size = androidx.compose.ui.geometry.Size(120f, 60f))
                                    drawRect(color = Color(0xFF0D9488).copy(alpha = 0.3f), topLeft = Offset(w/2 - 15f, h/2 - 10f), size = androidx.compose.ui.geometry.Size(15f, 60f))
                                    drawRect(color = Color(0xFF0D9488).copy(alpha = 0.4f), topLeft = Offset(w/2 + 10f, h/2 - 30f), size = androidx.compose.ui.geometry.Size(15f, 80f))
                                    val trendPath = androidx.compose.ui.graphics.Path().apply {
                                        moveTo(w/2 - 50f, h/2 + 30f)
                                        quadraticTo(w/2 - 10f, h/2 + 10f, w/2 + 25f, h/2 - 25f)
                                    }
                                    drawPath(trendPath, color = Color(0xFFFFB300), style = Stroke(width = 5f, cap = StrokeCap.Round))
                                }
                                "Littérature" -> {
                                    drawCircle(color = Color(0xFFDB2777).copy(alpha = 0.07f), radius = 55f, center = Offset(w/2, h/2))
                                    drawRect(color = Color.White, topLeft = Offset(w/2 - 30f, h/2 - 25f), size = androidx.compose.ui.geometry.Size(60f, 50f))
                                    drawRect(color = Color(0xFFDB2777), topLeft = Offset(w/2 - 32f, h/2 - 27f), size = androidx.compose.ui.geometry.Size(64f, 54f), style = Stroke(width = 3f))
                                    drawLine(color = Color.Gray, start = Offset(w/2 - 24f, h/2 - 12f), end = Offset(w/2 - 6f, h/2 - 12f), strokeWidth = 2f)
                                    drawLine(color = Color.Gray, start = Offset(w/2 + 6f, h/2 - 12f), end = Offset(w/2 + 24f, h/2 - 12f), strokeWidth = 2f)
                                }
                                else -> {
                                    drawOval(color = Color(0xFF005EDA).copy(alpha = 0.08f), topLeft = Offset(15f, 100f), size = androidx.compose.ui.geometry.Size(110f, 60f))
                                    val path = androidx.compose.ui.graphics.Path().apply {
                                        moveTo(70f, 20f)
                                        lineTo(20f, 120f)
                                        lineTo(120f, 120f)
                                        close()
                                    }
                                    drawPath(path, color = Color(0xFF005EDA).copy(alpha = 0.15f))
                                    drawPath(path, color = Color(0xFF005EDA), style = Stroke(width = 3f, cap = StrokeCap.Round))
                                    drawCircle(color = Color(0xFFFFB300), radius = 22f, center = Offset(70f, 65f), style = Stroke(width = 4f))
                                }
                            }
                        }
                    }
                }
            }
        }

        item {
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        1.dp,
                        MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f),
                        RoundedCornerShape(24.dp)
                    ),
                elevation = CardDefaults.cardElevation(1.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                "Momentum Hebdomadaire",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                "Temps d'étude par jour (heures)",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            modifier = Modifier
                                .clip(RoundedCornerShape(99.dp))
                                .background(Color(0xFFE8F8EF))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Icon(Icons.Default.TrendingUp, contentDescription = "Trend", tint = Color(0xFF2E7D32), modifier = Modifier.size(14.dp))
                            Text("+12%", style = MaterialTheme.typography.labelSmall, color = Color(0xFF2E7D32), fontWeight = FontWeight.Bold)
                        }
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(80.dp),
                        verticalAlignment = Alignment.Bottom,
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        listOf(30, 75, 45, 95, 60).forEachIndexed { i, size ->
                            val isPeak = (i == 3)
                            Box(
                                modifier = Modifier
                                    .width(22.dp)
                                    .fillMaxHeight(size / 100f)
                                    .clip(RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp))
                                    .background(if (isPeak) Color(0xFF52C77A) else bannerBg.copy(alpha = 0.25f))
                            )
                        }
                    }
                }
            }
        }

        item {
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = bannerBg),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text("Mode Entraînement", style = MaterialTheme.typography.titleLarge, color = Color.White, fontWeight = FontWeight.Bold)
                    Text("Progressez pas à pas. Relevez le quizz d'évaluation flashcards débloqué !", style = MaterialTheme.typography.bodyMedium, color = Color.White.copy(alpha = 0.85f))
                    Spacer(modifier = Modifier.height(14.dp))
                    Button(
                        onClick = onStartQuiz,
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.18f)),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Start, modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                            Box(modifier = Modifier.size(36.dp).clip(RoundedCornerShape(8.dp)).background(Color.White.copy(alpha = 0.2f)), contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.QuestionAnswer, contentDescription = null, tint = Color.White)
                            }
                            Spacer(modifier = Modifier.width(14.dp))
                            Column {
                                Text("Lancer le Quiz du Chapitre", fontWeight = FontWeight.Bold, color = Color.White, style = MaterialTheme.typography.bodyMedium)
                                Text("Questions corrigées avec indices éducatifs complets.", color = Color.White.copy(alpha = 0.75f), style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Programme & Chapitres", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.clickable { expandAll = !expandAll }) {
                    Text(text = if (expandAll) "Replier Tout" else "Déployer Tout", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = bannerBg)
                    Text(" ⇅ ", style = MaterialTheme.typography.bodyLarge, color = bannerBg)
                }
            }
        }

        itemsIndexed(topics) { index, topic ->
            val isExpanded = expandedTopics.contains(index)
            Card(
                onClick = {
                    if (topic.isUnlocked) {
                        expandedTopics = if (isExpanded) expandedTopics - index else expandedTopics + index
                    }
                },
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (topic.isUnlocked) MaterialTheme.colorScheme.surfaceContainerLowest else MaterialTheme.colorScheme.surfaceContainerLow.copy(alpha = 0.5f)
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .alpha(if (topic.isUnlocked) 1f else 0.6f)
                    .border(
                        1.dp,
                        if (topic.isUnlocked) MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f) else Color.Transparent,
                        RoundedCornerShape(24.dp)
                    )
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.weight(1f)) {
                            Box(
                                modifier = Modifier.size(44.dp).clip(CircleShape).background(
                                    if (topic.isDone) Color(0xFFE8F8EF) else if (topic.isUnlocked) bannerBg.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceContainerHighest
                                ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = if (topic.isDone) Icons.Default.CheckCircle else if (topic.isUnlocked) Icons.Default.PlayArrow else Icons.Default.Lock,
                                    contentDescription = null,
                                    tint = if (topic.isDone) Color(0xFF2E7D32) else if (topic.isUnlocked) bannerBg else MaterialTheme.colorScheme.outline
                                )
                            }
                            Column {
                                Text(topic.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                                Text(topic.subtitle, style = MaterialTheme.typography.labelSmall, color = if (topic.isUnlocked && !topic.isDone) bannerBg else MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                        Icon(
                            imageVector = if (isExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.outlineVariant
                        )
                    }

                    if (topic.isUnlocked && topic.progress != null && topic.progress < 1f) {
                        LinearProgressIndicator(
                            progress = { topic.progress },
                            color = bannerBg,
                            trackColor = Color(0xFFE0E0E0),
                            modifier = Modifier.fillMaxWidth().height(6.dp).padding(horizontal = 16.dp).clip(RoundedCornerShape(3.dp))
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                    }

                    AnimatedVisibility(
                        visible = isExpanded && topic.lessons.isNotEmpty(),
                        enter = expandVertically() + fadeIn(),
                        exit = shrinkVertically() + fadeOut()
                    ) {
                        Column(modifier = Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceContainerLow).padding(vertical = 4.dp)) {
                            topic.lessons.forEach { lesson ->
                                val finalDone = lesson.isDone || revisedLessons.contains(lesson.title)
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            if (lesson.isUnlocked) {
                                                activeRevisionLesson = Pair(lesson.title, getFicheNotes(lesson.title))
                                            }
                                        }
                                        .padding(horizontal = 24.dp, vertical = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = if (finalDone) Icons.Default.CheckCircle else if (lesson.isUnlocked) Icons.Default.PlayCircleOutline else Icons.Default.Lock,
                                        contentDescription = null,
                                        tint = if (finalDone) Color(0xFF52C77A) else if (lesson.isUnlocked) bannerBg else MaterialTheme.colorScheme.outline,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(lesson.title, style = MaterialTheme.typography.bodyMedium, color = if (lesson.isUnlocked) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.outline, fontWeight = FontWeight.SemiBold)
                                        if (lesson.isUnlocked) {
                                            Text("Cliquez pour étudier la fiche de révision", style = MaterialTheme.typography.labelSmall, color = bannerBg.copy(alpha = 0.8f))
                                        }
                                    }
                                    Text(lesson.duration, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    activeRevisionLesson?.let { mem ->
        AlertDialog(
            onDismissRequest = { activeRevisionLesson = null },
            title = {
                Column {
                    Text("Fiche Mélo • $subjectTitle", style = MaterialTheme.typography.labelSmall, color = bannerBg, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(mem.first, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
                }
            },
            text = {
                Box(modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(bannerBg.copy(alpha = 0.08f)).padding(12.dp)) {
                    Text(mem.second, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurface, lineHeight = 20.sp)
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        revisedLessons = revisedLessons + mem.first
                        viewModel.triggerToast("Fiche Révisée ! +5 XP et progression augmentée ! 🎓✨")
                        activeRevisionLesson = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = bannerBg)
                ) {
                    Text("Lu & Révisé 🎓", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { activeRevisionLesson = null }) {
                    Text("Fermer", color = MaterialTheme.colorScheme.outline)
                }
            }
        )
    }
}

data class TopicItem(
    val title: String,
    val subtitle: String,
    val isDone: Boolean,
    val isUnlocked: Boolean,
    val progress: Float? = null,
    val lessons: List<LessonItem> = emptyList()
)

data class LessonItem(
    val title: String,
    val duration: String,
    val isDone: Boolean,
    val isUnlocked: Boolean
)

fun getFicheNotes(title: String): String {
    return when (title) {
        "Calcul de Dérivées Usuelles" -> "• f(x) = x^n => f'(x) = n·x^(n-1)\n• f(x) = ln(x) => f'(x) = 1/x\n• f(x) = e^x => f'(x) = e^x\n💡 Astuce : produit d'équations (u·v)' = u'v + uv'."
        "Formules de composition et dérivabilité" -> "• Composition (f∘g)'(x) = g'(x) · f'(g(x))\n• Pour u^n, dérivée n·u'·u^(n-1)\n• Pour e^u, dérivée u'·e^u."
        "Limites et Continuité des fonctions de Riemann" -> "• Continue en a ssi lim_{x→a} f(x) = f(a).\n• TVI : si continue sur [a,b], toute valeur intermédiaire entre f(a) et f(b) est atteinte au moins une fois par f."
        "Calcul de primitives et aires géométriques" -> "• F est primitive de f ssi F' = f.\n• L'intégrale ∫_a^b f(x)dx = F(b) - F(a) représente l'aire arithmétique située sous la courbe."
        "Snell-Descartes et prisme optique" -> "• Réfraction : n1 · sin(θ1) = n2 · sin(θ2).\n• L'indice n dépend de la longueur d'onde, d'où la dispersion chromatique par le prisme."
        "Lentilles convergentes et formation d'images" -> "• Formule de Descartes : 1/OA' - 1/OA = 1/f'\n• Grandissement transversal : γ = OA' / OA."
        "Lois de Newton et mécanique d'inertie" -> "• 1ère loi : principe d'inertie.\n• 2ème loi : Somme forces = m · a.\n• 3ème loi : Action-Réaction : F_{A→B} = -F_{B→A}."
        "Athènes et le siècle de Périclès" -> "• Vème s. av. J-C : Démocratie d'Athènes directe civique.\n• Périclès instaure le salaire civique (misthos) et fait reconstruire l'Acropole d'Athènes."
        "La Révolution Industrielle et le Charbon" -> "• Watt crée la machine à vapeur en 1769.\n• Le charbon est l'énergie motrice transformant l'exode et l'urbanisation."
        "Offre et Demande : Loi du Marché" -> "• L'offre croît avec le prix, la demande recule.\n• L'équilibre se forme au croisement formant le prix d'échange stable."
        "Le Modèle IS-LM Keynesien" -> "• Équilibre IS (investissement-épargne) and LM (demande-offre de monnaie).\n• Outil budgétaire de relance étatique pour réduire le sous-emploi."
        "Le Romantisme chez Victor Hugo" -> "• Courant du XIXème prônant la subjectivité du Moi, le mal du siècle, l'esthétique lyrique s'opposant au classicisme."
        "Le Spleen et l'Idéal baudelairien" -> "• Fleurs du mal (1857).\n• Spleen : angoisse d'étouffement, temps cupide.\n• Idéal : extase divine par les synesthésies sensuelles."
        else -> "Fiche de cours générale pour mémoriser les notions clés.\n\nFaites un break Pomodoro régulier de 5-10 minutes !"
    }
}


// SCREEN 2: Multiple Choice Quiz Flipping Flashcard Screen

@Composable
fun QuizScreen(
    viewModel: StudyViewModel,
    onBack: () -> Unit,
    onQuizComplete: () -> Unit
) {
    // 1. Data model definitions inside code
    val categoriesList = remember {
        listOf(
            QuizCategory(
                id = "kotlin",
                title = "Kotlin & Dev Android",
                subtitle = "Variables, Coroutines, Compose & États",
                icon = Icons.Default.Code,
                color = Color(0xFF8B5CF6), // Purple
                questions = listOf(
                    QuizQuestion(
                        questionText = "Quelle est la principale différence entre 'val' et 'const val' en Kotlin ?",
                        options = listOf(
                            "val est évalué à la compilation, const val à l'exécution",
                            "val est évalué à l'exécution, const val à la compilation",
                            "Il n'y a aucune différence réelle à l'exécution",
                            "const val permet de modifier la référence"
                        ),
                        correctIndex = 1,
                        explanation = "'const val' désigne une constante connue au moment de la compilation de l'application, tandis que 'val' est évaluée dynamiquement à l'exécution.",
                        hint = "Pensez au moment où le compilateur écrit le binaire de l'application."
                    ),
                    QuizQuestion(
                        questionText = "Que fait l'opérateur '?:' (Operateur Elvis) en Kotlin ?",
                        options = listOf(
                            "Il compare deux variables par identité physique",
                            "Il retourne une valeur de rechange si la gauche est nulle",
                            "Il déclenche une exception de non-nullité",
                            "Il boucle jusqu'à ce que la valeur soit non-nulle"
                        ),
                        correctIndex = 1,
                        explanation = "L'opérateur Elvis '?:' permet de fournir une valeur de repli si l'expression située à sa gauche vaut 'null'.",
                        hint = "C'est l'adorable mèche de cheveux d'Elvis Presley !"
                    ),
                    QuizQuestion(
                        questionText = "Dans Jetpack Compose, quelle fonction préserve l'état au travers des recompositions ?",
                        options = listOf(
                            "remember",
                            "persistState",
                            "saveValue",
                            "observeState"
                        ),
                        correctIndex = 0,
                        explanation = "La fonction 'remember' permet de mémoriser une valeur recalculée lors de la première composition, et la retourne lors de chaque recomposition.",
                        hint = "C'est le mot anglais pour 'se souvenir'."
                    ),
                    QuizQuestion(
                        questionText = "Quelle portée de Coroutine (CoroutineScope) est liée au cycle de vie du ViewModel ?",
                        options = listOf(
                            "GlobalScope",
                            "Dispatchers.IO",
                            "viewModelScope",
                            "uiScope"
                        ),
                        correctIndex = 2,
                        explanation = "'viewModelScope' est automatiquement annulé dès que le ViewModel associé est détruit, évitant les fuites de mémoire.",
                        hint = "Il comporte le nom du composant d'architecture standard MVVM."
                    ),
                    QuizQuestion(
                        questionText = "Quel élément Jetpack Compose permet de créer des listes performantes et recyclables ?",
                        options = listOf(
                            "ScrollView",
                            "RecyclerViewAdapter",
                            "LazyColumn",
                            "Column(modifierScroll)"
                        ),
                        correctIndex = 2,
                        explanation = "'LazyColumn' n'affiche et ne compose que les éléments visibles sur l'écran, ce qui en fait l'équivalent moderne du RecyclerView.",
                        hint = "Il est dit 'fainéant' (lazy) car il ne fait rien d'inutile."
                    )
                )
            ),
            QuizCategory(
                id = "science",
                title = "Sciences & Cosmos",
                subtitle = "Système solaire, corps humain et physique",
                icon = Icons.Default.School,
                color = Color(0xFF0EA5E9), // Sky Blue
                questions = listOf(
                    QuizQuestion(
                        questionText = "Combien de temps met la lumière du Soleil pour atteindre la Terre ?",
                        options = listOf(
                            "Environ 8 secondes",
                            "Environ 8 minutes",
                            "Environ 2 heures",
                            "C'est instantané"
                        ),
                        correctIndex = 1,
                        explanation = "Voyageant à la vitesse de la lumière (300 000 km/s), l'onde solaire met environ 8 minutes et 20 secondes à traverser les 150 millions de kilomètres nous séparant du Soleil.",
                        hint = "C'est une durée proche de celle de la pause Pomodoro classique !"
                    ),
                    QuizQuestion(
                        questionText = "Quel organe humain gère principalement l'équilibre du corps ?",
                        options = listOf(
                            "Le cervelet",
                            "L'oreille interne",
                            "La rétine de l'œil",
                            "Le nerf spinal"
                        ),
                        correctIndex = 1,
                        explanation = "Le système vestibulaire niché dans l'oreille interne envoie des signaux au cerveau pour réguler l'équilibre statique et dynamique.",
                        hint = "Cet organe héberge aussi l'ouïe."
                    ),
                    QuizQuestion(
                        questionText = "Quelle force majeure retient l'atmosphère terrestre en place ?",
                        options = listOf(
                            "La force centrifuge",
                            "La force électromagnétique",
                            "La gravité",
                            "La pression hydrostatique"
                        ),
                        correctIndex = 2,
                        explanation = "La gravité de la Terre retient les molécules gazeuses de notre atmosphère, les empêchant de s'échapper dans le vide spatial.",
                        hint = "C'est la même force qui fait tomber les pommes vers le sol."
                    ),
                    QuizQuestion(
                        questionText = "Quel gaz est le plus abondant dans l'air que nous respirons ?",
                        options = listOf(
                            "L'Oxygène (O2)",
                            "L'Azote (N2)",
                            "Le Dioxyde de Carbone (CO2)",
                            "L'Argon"
                        ),
                        correctIndex = 1,
                        explanation = "L'air sec de la Terre se compose d'environ 78.08 % d'azote (Diazote N2) et de 20.95 % d'oxygène.",
                        hint = "Ce gaz commence par la lettre N (Nitrogen en anglais)."
                    ),
                    QuizQuestion(
                        questionText = "Quelle planète est surnommée la planète rouge ?",
                        options = listOf(
                            "Vénus",
                            "Mars",
                            "Jupiter",
                            "Saturne"
                        ),
                        correctIndex = 1,
                        explanation = "Mars doit son surnom et son éclat rougeâtre à la présence d'oxydes de fer (semblable à de la rouille) à sa surface.",
                        hint = "Elle doit son nom au dieu romain de la guerre."
                    )
                )
            ),
            QuizCategory(
                id = "culture",
                title = "Arts & Culture Générale",
                subtitle = "Histoire du monde, peintres célèbres & géographie",
                icon = Icons.Default.Star,
                color = Color(0xFFF59E0B), // Orange/Amber
                questions = listOf(
                    QuizQuestion(
                        questionText = "Qui a peint la légendaire voûte de la Chapelle Sixtine à Rome ?",
                        options = listOf(
                            "Léonard de Vinci",
                            "Michel-Ange",
                            "Raphaël",
                            "Clément VII"
                        ),
                        correctIndex = 1,
                        explanation = "Michel-Ange a peint les plafonds de la Chapelle Sixtine entre 1508 et 1512 à la demande du pape Jules II.",
                        hint = "Son nom évoque un archange sculpteur et peintre."
                    ),
                    QuizQuestion(
                        questionText = "Dans quelle commune trouve-t-on les arènes romaines les mieux conservées de France ?",
                        options = listOf(
                            "Arles",
                            "Nîmes",
                            "Orange",
                            "Vienne"
                        ),
                        correctIndex = 1,
                        explanation = "Les arènes de Nîmes sont de l'époque flavienne (Ier siècle de notre ère) et sont remarquablement conservées dans le Gard.",
                        hint = "La ville est célèbre pour son Crocodile et son palmier."
                    ),
                    QuizQuestion(
                        questionText = "Quel dramaturge a composé la fameuse tragédie romantique 'Les Misérables' ?",
                        options = listOf(
                            "Gustave Flaubert",
                            "Victor Hugo",
                            "Émile Zola",
                            "Honoré de Balzac"
                        ),
                        correctIndex = 1,
                        explanation = "Victor Hugo, poète et écrivain humaniste engagé, a publié 'Les Misérables' en 1862.",
                        hint = "Il a prononcé des plaidoyers mémorables contre la peine de mort."
                    ),
                    QuizQuestion(
                        questionText = "Quel est le chef d'expédition crédité pour le premier tour du monde maritime ?",
                        options = listOf(
                            "Christophe Colomb",
                            "Vasco de Gama",
                            "Fernand de Magellan",
                            "James Cook"
                        ),
                        correctIndex = 2,
                        explanation = "La flotte de Magellan complète le premier tour du monde (première circumnavigation) en terminant le voyage sous le commandement d'Elcano en 1522.",
                        hint = "Un détroit porte son nom tout au sud de l'Amérique latine."
                    ),
                    QuizQuestion(
                        questionText = "Quelle est la capitale officielle de l'Australie ?",
                        options = listOf(
                            "Sydney",
                            "Melbourne",
                            "Canberra",
                            "Perth"
                        ),
                        correctIndex = 2,
                        explanation = "Canberra a été édifiée ex-nihilo en 1913 comme compromis pour clore la guerre de rivalité entre Sydney et Melbourne.",
                        hint = "Ce n'est ni Sydney ni sa rivale du sud."
                    )
                )
            ),
            QuizCategory(
                id = "logique",
                title = "Logique & Énigmes",
                subtitle = "Raisonnement rationnel et gymnastique mentale",
                icon = Icons.Default.Info,
                color = Color(0xFFF43F5E), // Rose
                questions = listOf(
                    QuizQuestion(
                        questionText = "Si une horloge prend 5 minutes d'avance par heure, de combien aura-t-elle avancé en 12 heures ?",
                        options = listOf(
                            "30 minutes",
                            "1 heure",
                            "10 minutes",
                            "2 heures"
                        ),
                        correctIndex = 1,
                        explanation = "En 12 heures, elle avance de 5 min * 12 = 60 minutes, soit exactement une heure entière.",
                        hint = "Multipliez 5 par 12 et convertissez les minutes en heures."
                    ),
                    QuizQuestion(
                        questionText = "Un berger a 17 brebis. Elles meurent toutes sauf 9. Combien de brebis saines reste-t-il ?",
                        options = listOf(
                            "8 brebis",
                            "17 brebis",
                            "9 brebis",
                            "Aucune"
                        ),
                        correctIndex = 2,
                        explanation = "Le texte dit 'toutes meurent sauf 9'. Les 9 brebis restantes sont donc celles qui ont survécu !",
                        hint = "Lisez attentivement l'exclusion de la phrase."
                    ),
                    QuizQuestion(
                        questionText = "Trouvez la lettre logique venant compléter la suite : U, D, T, Q, C, S, S, O...",
                        options = listOf(
                            "N",
                            "T",
                            "D",
                            "P"
                        ),
                        correctIndex = 0,
                        explanation = "Ces lettres représentent les initiales des premiers chiffres : Un, Deux, Trois, Quatre, Cinq, Six, Sept, Huit... Le prochain est Neuf, donc la lettre 'N' !",
                        hint = "Essayez de compter à voix haute depuis le début."
                    ),
                    QuizQuestion(
                        questionText = "Un avion s'écrase sur la frontière franco-belge. Où enterre-t-on légalement les survivants ?",
                        options = listOf(
                            "En France",
                            "En Belgique",
                            "Dans leur pays d'origine",
                            "On n'enterre pas les survivants"
                        ),
                        correctIndex = 3,
                        explanation = "On n'enterre jamais des survivants !",
                        hint = "Réfléchissez au statut de vie des passagers après le crash."
                    ),
                    QuizQuestion(
                        questionText = "La maman de Luc a trois enfants : Marc, Julien et... ?",
                        options = listOf(
                            "Luc",
                            "Pierre",
                            "Laurence",
                            "Marie"
                        ),
                        correctIndex = 0,
                        explanation = "C'est la maman de Luc ! Ses enfants se nomment Marc, Julien et... Luc.",
                        hint = "Le nom du troisième enfant figure déjà au début de l'énoncé."
                    )
                )
            )
        )
    }

    // 2. Playback state machine
    var quizState by remember { mutableStateOf(QuizState.Selecting) }
    var activeCategory by remember { mutableStateOf<QuizCategory?>(null) }
    
    // Loaded questions - allows shuffling or dynamic reloading
    var runningQuestions by remember { mutableStateOf<List<QuizQuestion>>(emptyList()) }
    
    // Active session status
    var currentQuestionIndex by remember { mutableStateOf(0) }
    var score by remember { mutableStateOf(0) }
    var streak by remember { mutableStateOf(0) }
    var selectedOptionIndex by remember { mutableStateOf<Int?>(null) }
    var isAnswered by remember { mutableStateOf(false) }
    var isFlipped by remember { mutableStateOf(false) }

    // Visual countdown seconds
    var timerSeconds by remember { mutableStateOf(30) }
    var isTimerActive by remember { mutableStateOf(true) }

    // Keep statistics history of results
    var resultsSummaryList by remember { mutableStateOf<List<QuizResultPair>>(emptyList()) }

    // Clock ticker trigger
    LaunchedEffect(quizState, currentQuestionIndex, isAnswered, isTimerActive) {
        if (quizState == QuizState.Playing && !isAnswered && isTimerActive) {
            timerSeconds = 30
            while (timerSeconds > 0 && !isAnswered) {
                delay(1000)
                timerSeconds -= 1
            }
            if (timerSeconds == 0 && !isAnswered) {
                // Time up! Force feedback
                selectedOptionIndex = -1
                isAnswered = true
                streak = 0
                val activeQ = runningQuestions[currentQuestionIndex]
                resultsSummaryList = resultsSummaryList + QuizResultPair(
                    questionText = activeQ.questionText,
                    userSelectedStr = "Temps écoulé",
                    correctStr = activeQ.options[activeQ.correctIndex],
                    wasCorrect = false
                )
                viewModel.triggerToast("Temps écoulé ! Économisez vos neurones.")
            }
        }
    }

    // 3D rotation animation value for card flipping (Hints)
    val rotation by animateFloatAsState(
        targetValue = if (isFlipped) 180f else 0f,
        animationSpec = tween(550, easing = FastOutSlowInEasing),
        label = "hintRotation"
    )

    // UI layouts based on state machine
    when (quizState) {
        QuizState.Selecting -> {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 24.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                contentPadding = PaddingValues(top = 16.dp, bottom = 48.dp)
            ) {
                // Header
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = onBack,
                            modifier = Modifier
                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f), CircleShape)
                                .testTag("quiz_back_button")
                        ) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                        }
                        Spacer(modifier = Modifier.width(16.dp))
                        Text(
                            text = "Défis de connaissances",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f)
                        ),
                        shape = RoundedCornerShape(24.dp)
                    ) {
                        Column(modifier = Modifier.padding(20.dp)) {
                            Text(
                                "🧠 Stimulez votre cerveau",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                "Sélectionnez un sujet ci-dessous pour lancer un quiz interactif. Chaque question possède un chrono de 30 secondes et un historique d'explications !",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            Spacer(modifier = Modifier.height(12.dp))
                            // Refresh questions pool simulator logic
                            Row(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(99.dp))
                                    .background(MaterialTheme.colorScheme.primary)
                                    .clickable {
                                        viewModel.triggerToast("Nouveau lot de questions chargé !")
                                    }
                                    .padding(horizontal = 14.dp, vertical = 8.dp)
                                    .testTag("shuffle_questions_button"),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(Icons.Default.Refresh, contentDescription = "Refresh", tint = Color.White)
                                Text("Recharger / Mélanger les pools", fontSize = 12.sp, color = Color.White, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        "Suites de sujets disponibles :",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Grid list of themes
                items(categoriesList.size) { index ->
                    val cat = categoriesList[index]
                    Card(
                        onClick = {
                            activeCategory = cat
                            // Load shuffled copy of questions as requested
                            runningQuestions = cat.questions.shuffled()
                            currentQuestionIndex = 0
                            score = 0
                            streak = 0
                            selectedOptionIndex = null
                            isAnswered = false
                            isFlipped = false
                            resultsSummaryList = emptyList()
                            quizState = QuizState.Playing
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("category_item_${cat.id}"),
                        shape = RoundedCornerShape(24.dp),
                        border = BorderStroke(1.dp, cat.color.copy(alpha = 0.2f)),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                        elevation = CardDefaults.cardElevation(2.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(18.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(56.dp)
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(cat.color.copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = cat.icon,
                                    contentDescription = cat.title,
                                    tint = cat.color,
                                    modifier = Modifier.size(28.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(16.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = cat.title,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = cat.subtitle,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            IconButton(
                                onClick = {
                                    activeCategory = cat
                                    runningQuestions = cat.questions.shuffled()
                                    currentQuestionIndex = 0
                                    score = 0
                                    streak = 0
                                    selectedOptionIndex = null
                                    isAnswered = false
                                    isFlipped = false
                                    resultsSummaryList = emptyList()
                                    quizState = QuizState.Playing
                                },
                                modifier = Modifier.background(cat.color.copy(alpha = 0.1f), CircleShape)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PlayArrow,
                                    contentDescription = "Start",
                                    tint = cat.color
                                )
                            }
                        }
                    }
                }
            }
        }

        QuizState.Playing -> {
            val cat = activeCategory ?: return
            val activeQ = runningQuestions.getOrNull(currentQuestionIndex) ?: return

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Header status
                Column(modifier = Modifier.padding(top = 16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = { quizState = QuizState.Selecting },
                            modifier = Modifier.background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f), CircleShape)
                        ) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = MaterialTheme.colorScheme.onSurface)
                        }

                        // Theme indicator
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(99.dp))
                                .background(cat.color.copy(alpha = 0.15f))
                                .padding(horizontal = 12.dp, vertical = 4.dp)
                        ) {
                            Text(cat.title, fontSize = 11.sp, color = cat.color, fontWeight = FontWeight.Bold)
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(Icons.Default.Star, contentDescription = "Streak", tint = cat.color, modifier = Modifier.size(16.dp))
                            Text(
                                text = "Score: $score/5",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                    
                    Spacer(modifier = Modifier.height(12.dp))

                    // Progress indicators
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Question ${currentQuestionIndex + 1} sur 5",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontWeight = FontWeight.Bold
                        )
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(2.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (streak > 0) {
                                Text("🔥 $streak", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Black)
                                Spacer(modifier = Modifier.width(4.dp))
                            }
                            // Seconds ticker visually
                            Text(
                                text = "${timerSeconds}s",
                                style = MaterialTheme.typography.bodySmall,
                                color = if (timerSeconds < 10) MaterialTheme.colorScheme.error else cat.color,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }
                    
                    Spacer(modifier = Modifier.height(6.dp))

                    // Double-progress bars: Question counter + Active clock decaying
                    Box(modifier = Modifier.fillMaxWidth()) {
                        LinearProgressIndicator(
                            progress = { (currentQuestionIndex + 1) / 5f },
                            color = cat.color,
                            trackColor = cat.color.copy(alpha = 0.15f),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(CircleShape)
                        )
                    }
                }

                // Question card area with 3D Flipping Hints capability
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .padding(vertical = 16.dp),
                    verticalArrangement = Arrangement.Center
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(190.dp)
                            .graphicsLayer {
                                rotationY = rotation
                                cameraDistance = 14f * density
                            }
                            .clickable { isFlipped = !isFlipped },
                        contentAlignment = Alignment.Center
                    ) {
                        if (rotation <= 90f) {
                            // Question Front
                            Card(
                                modifier = Modifier.fillMaxSize(),
                                shape = RoundedCornerShape(24.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .padding(20.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.Center
                                ) {
                                    Text(
                                        text = "QUESTION",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = cat.color,
                                        letterSpacing = 1.sp
                                    )
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Text(
                                        text = activeQ.questionText,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        textAlign = TextAlign.Center,
                                        lineHeight = 22.sp
                                    )
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(99.dp))
                                            .background(cat.color.copy(alpha = 0.1f))
                                            .padding(horizontal = 10.dp, vertical = 4.dp)
                                    ) {
                                        Icon(Icons.Default.Info, contentDescription = null, tint = cat.color)
                                        Text(
                                            "Cliquez pour voir l'indice",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = cat.color,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        } else {
                            // Hint Back
                            Card(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .graphicsLayer { rotationY = 180f },
                                shape = RoundedCornerShape(24.dp),
                                colors = CardDefaults.cardColors(containerColor = cat.color),
                                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .padding(20.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.Center
                                ) {
                                    Text(
                                        text = "INDICE DE RECHERCHE",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White.copy(alpha = 0.75f),
                                        letterSpacing = 1.sp
                                    )
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Text(
                                        text = activeQ.hint,
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White,
                                        textAlign = TextAlign.Center,
                                        lineHeight = 20.sp
                                    )
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Text(
                                        text = "Re-cliquez pour revenir",
                                        fontStyle = FontStyle.Italic,
                                        fontSize = 10.sp,
                                        color = Color.White.copy(alpha = 0.75f)
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Option Selection List - Instant Colorful Response
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        activeQ.options.forEachIndexed { optIndex, choiceLabel ->
                            val isThisSelected = selectedOptionIndex == optIndex
                            val isCorrectAnswer = optIndex == activeQ.correctIndex

                            // Determining highlight styles dynamically
                            val optionBgColor by animateColorAsState(
                                targetValue = if (isAnswered) {
                                    if (isCorrectAnswer) {
                                        Color(0xFFDCFCE7) // Glowing solid Green
                                    } else if (isThisSelected) {
                                        Color(0xFFFEE2E2) // Glowing red for wrong selection
                                    } else {
                                        MaterialTheme.colorScheme.surfaceContainerLowest
                                    }
                                } else if (isThisSelected) {
                                    cat.color.copy(alpha = 0.12f)
                                } else {
                                    MaterialTheme.colorScheme.surfaceContainerLowest
                                },
                                animationSpec = tween(250),
                                label = "optionBg"
                            )

                            val optionBorderColor by animateColorAsState(
                                targetValue = if (isAnswered) {
                                    if (isCorrectAnswer) {
                                        Color(0xFF22C55E) // Green border
                                    } else if (isThisSelected) {
                                        Color(0xFFEF4444) // Red border
                                    } else {
                                        Color.Transparent
                                    }
                                } else if (isThisSelected) {
                                    cat.color
                                } else {
                                    MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)
                                },
                                animationSpec = tween(250),
                                label = "optionBorder"
                            )

                            val contentScale by animateFloatAsState(
                                targetValue = if (isThisSelected && isAnswered) 1.03f else 1.0f,
                                animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
                                label = "optionScale"
                            )

                            Card(
                                onClick = {
                                    if (!isAnswered) {
                                        selectedOptionIndex = optIndex
                                        isAnswered = true
                                        val answeredCorrectly = (optIndex == activeQ.correctIndex)
                                        if (answeredCorrectly) {
                                            score += 1
                                            streak += 1
                                            viewModel.triggerToast("Correct ! 🎉 +1")
                                        } else {
                                            streak = 0
                                            viewModel.triggerToast("Oups ! Lisez l'explication.")
                                        }

                                        // Store for final history summary
                                        resultsSummaryList = resultsSummaryList + QuizResultPair(
                                            questionText = activeQ.questionText,
                                            userSelectedStr = choiceLabel,
                                            correctStr = activeQ.options[activeQ.correctIndex],
                                            wasCorrect = answeredCorrectly
                                        )
                                    }
                                },
                                shape = RoundedCornerShape(20.dp),
                                colors = CardDefaults.cardColors(containerColor = optionBgColor),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .graphicsLayer {
                                        scaleX = contentScale
                                        scaleY = contentScale
                                    }
                                    .border(
                                        width = if (isThisSelected || (isAnswered && isCorrectAnswer)) 2.dp else 1.dp,
                                        color = optionBorderColor,
                                        shape = RoundedCornerShape(20.dp)
                                    )
                                    .testTag("option_item_${optIndex}"),
                                elevation = CardDefaults.cardElevation(if (isThisSelected) 2.dp else 0.dp)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 16.dp, vertical = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        // Option Code index indicator A, B, C, D
                                        val bubbleColor = if (isAnswered) {
                                            if (isCorrectAnswer) Color(0xFF22C55E) else if (isThisSelected) Color(0xFFEF4444) else MaterialTheme.colorScheme.surfaceVariant
                                        } else if (isThisSelected) {
                                            cat.color
                                        } else {
                                            MaterialTheme.colorScheme.surfaceVariant
                                        }

                                        val bubbleTextColor = if (isAnswered && (isCorrectAnswer || isThisSelected)) {
                                            Color.White
                                        } else if (isThisSelected) {
                                            Color.White
                                        } else {
                                            MaterialTheme.colorScheme.onSurfaceVariant
                                        }

                                        Box(
                                            modifier = Modifier
                                                .size(30.dp)
                                                .clip(CircleShape)
                                                .background(bubbleColor),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = when (optIndex) {
                                                    0 -> "A"
                                                    1 -> "B"
                                                    2 -> "C"
                                                    else -> "D"
                                                },
                                                fontWeight = FontWeight.Bold,
                                                color = bubbleTextColor,
                                                fontSize = 12.sp
                                            )
                                        }

                                        Spacer(modifier = Modifier.width(12.dp))

                                        Text(
                                            text = choiceLabel,
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = if (isThisSelected) FontWeight.Bold else FontWeight.Medium,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    }

                                    // Correct indicator check or cross
                                    if (isAnswered) {
                                        if (isCorrectAnswer) {
                                            Icon(Icons.Default.Check, contentDescription = "Juste", tint = Color(0xFF15803D))
                                        } else if (isThisSelected) {
                                            Icon(Icons.Default.Close, contentDescription = "Faux", tint = Color(0xFFB91C1C))
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Explanation slide up box inside play area
                    AnimatedVisibility(
                        visible = isAnswered,
                        enter = fadeIn() + expandVertically(expandFrom = Alignment.Top),
                        exit = fadeOut() + shrinkVertically(shrinkTowards = Alignment.Top)
                    ) {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 12.dp),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (selectedOptionIndex == activeQ.correctIndex) {
                                    Color(0xFFF0FDF4)
                                } else {
                                    Color(0xFFFEF2F2)
                                }
                            ),
                            border = BorderStroke(
                                1.dp,
                                if (selectedOptionIndex == activeQ.correctIndex) Color(0xFFBBF7D0) else Color(0xFFFECACA)
                            )
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Icon(
                                        imageVector = if (selectedOptionIndex == activeQ.correctIndex) Icons.Default.CheckCircle else Icons.Default.Warning,
                                        contentDescription = "Status",
                                        tint = if (selectedOptionIndex == activeQ.correctIndex) Color(0xFF16A34A) else Color(0xFFDC2626),
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Text(
                                        text = if (selectedOptionIndex == activeQ.correctIndex) "Explication • Correct !" else "Explication • Mauvais choix",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = if (selectedOptionIndex == activeQ.correctIndex) Color(0xFF16823D) else Color(0xFF991B1B)
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = activeQ.explanation,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    lineHeight = 16.sp
                                )
                            }
                        }
                    }
                }

                // Answer controllers (Next, Skip)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(
                        onClick = { quizState = QuizState.Selecting },
                        modifier = Modifier.testTag("skip_question_button")
                    ) {
                        Icon(Icons.Default.Flag, contentDescription = "Retour", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Changer sujet", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }

                    Button(
                        onClick = {
                            if (currentQuestionIndex < 4) {
                                currentQuestionIndex += 1
                                selectedOptionIndex = null
                                isAnswered = false
                                isFlipped = false
                            } else {
                                // Last question completed -> results state
                                quizState = QuizState.Results
                            }
                        },
                        enabled = isAnswered,
                        colors = ButtonDefaults.buttonColors(containerColor = cat.color),
                        shape = RoundedCornerShape(99.dp),
                        modifier = Modifier.testTag("next_question_button")
                    ) {
                        Text(
                            text = if (currentQuestionIndex < 4) "Suivant" else "Finaliser",
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(
                            imageVector = Icons.Default.ArrowForward,
                            contentDescription = "Forward",
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }

        QuizState.Results -> {
            val cat = activeCategory ?: return
            
            // Increment total hours slightly if user scored highly!
            LaunchedEffect(score) {
                if (score >= 4) {
                    // Update main statistics dynamically
                    viewModel.toggleTaskCompletion(com.example.data.Task(
                        title = "Défi Quiz ${cat.title} validé !",
                        subject = "Révision",
                        priority = "Moyenne",
                        isCompleted = true
                    ))
                }
            }

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp),
                contentPadding = PaddingValues(top = 16.dp, bottom = 48.dp)
            ) {
                // Header Celebration
                item {
                    Spacer(modifier = Modifier.height(16.dp))
                    Box(
                        modifier = Modifier
                            .size(120.dp)
                            .clip(CircleShape)
                            .background(cat.color.copy(alpha = 0.1f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = "Trophy",
                            tint = cat.color,
                            modifier = Modifier.size(64.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = when (score) {
                            5 -> "🏆 Sans faute parfait !"
                            4 -> "🌟 Excellent travail !"
                            3 -> "📚 Bien, continuez !"
                            else -> "💪 N'abandonnez pas !"
                        },
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Black,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Vous avez complété le défi en ${cat.title}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                }

                // Circular Progress Graph Score
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                        shape = RoundedCornerShape(28.dp),
                        elevation = CardDefaults.cardElevation(2.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier.size(140.dp)
                            ) {
                                Canvas(modifier = Modifier.fillMaxSize()) {
                                    drawCircle(
                                        color = cat.color.copy(alpha = 0.1f),
                                        style = Stroke(width = 12.dp.toPx())
                                    )
                                    drawArc(
                                        color = cat.color,
                                        startAngle = -90f,
                                        sweepAngle = 360f * (score / 5f),
                                        useCenter = false,
                                        style = Stroke(width = 12.dp.toPx(), cap = StrokeCap.Round)
                                    )
                                }
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        text = "$score / 5",
                                        style = MaterialTheme.typography.displaySmall,
                                        fontWeight = FontWeight.Black,
                                        color = cat.color
                                    )
                                    Text(
                                        text = "${score * 20}% de réussite",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(20.dp))
                            Text(
                                text = when (score) {
                                    5 -> "Incroyable ! Vos compétences sont au sommet. Vous avez assimilé chaque notion avec rigueur."
                                    4 -> "Très belle maîtrise ! Vous possédez d'excellentes bases sur ce thème d'étude."
                                    3 -> "Bon départ. Quelques relectures supplémentaires des fiches et vous atteindrez les sommets !"
                                    else -> "Ne vous découragez pas. L'apprentissage est fait d'essais et d'explications. Repassez le test pour vous améliorer !"
                                },
                                style = MaterialTheme.typography.bodyMedium,
                                textAlign = TextAlign.Center,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                // Interactive History review
                item {
                    Text(
                        "Analyse des questions :",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                items(resultsSummaryList.size) { rIndex ->
                    val pairObj = resultsSummaryList[rIndex]
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = if (pairObj.wasCorrect) Color(0xFFF0FDF4) else Color(0xFFFEF2F2)
                        ),
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.dp, if (pairObj.wasCorrect) Color(0xFFDCFCE7) else Color(0xFFFEE2E2))
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.Top
                            ) {
                                Text(
                                    text = pairObj.questionText,
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.weight(1f)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(99.dp))
                                        .background(if (pairObj.wasCorrect) Color(0xFF22C55E) else Color(0xFFEF4444))
                                        .padding(horizontal = 8.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = if (pairObj.wasCorrect) "Juste" else "Faux",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Color.White,
                                        fontWeight = FontWeight.Black
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Votre réponse : ${pairObj.userSelectedStr}",
                                style = MaterialTheme.typography.bodySmall,
                                fontStyle = FontStyle.Italic,
                                color = if (pairObj.wasCorrect) Color(0xFF15803D) else Color(0xFFB91C1C)
                            )
                            if (!pairObj.wasCorrect) {
                                Text(
                                    text = "Réponse attendue : ${pairObj.correctStr}",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF15803D)
                                )
                            }
                        }
                    }
                }

                // Actions buttons Recommencer / Changer Sujet
                item {
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                quizState = QuizState.Selecting
                            },
                            shape = RoundedCornerShape(99.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("change_theme_button"),
                            border = BorderStroke(1.5.dp, cat.color)
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp), tint = cat.color)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Changer sujet", fontWeight = FontWeight.Bold, color = cat.color)
                        }

                        Button(
                            onClick = {
                                runningQuestions = cat.questions.shuffled()
                                currentQuestionIndex = 0
                                score = 0
                                streak = 0
                                selectedOptionIndex = null
                                isAnswered = false
                                isFlipped = false
                                resultsSummaryList = emptyList()
                                quizState = QuizState.Playing
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = cat.color),
                            shape = RoundedCornerShape(99.dp),
                            modifier = Modifier
                                .weight(1.2f)
                                .testTag("restart_quiz_button")
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color.White)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Recommencer", fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    TextButton(onClick = onQuizComplete) {
                        Text("Accéder aux jalons trophées", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

// Result structure
data class QuizResultPair(
    val questionText: String,
    val userSelectedStr: String,
    val correctStr: String,
    val wasCorrect: Boolean
)

data class QuizQuestion(
    val questionText: String,
    val options: List<String>,
    val correctIndex: Int,
    val explanation: String,
    val hint: String
)

data class QuizCategory(
    val id: String,
    val title: String,
    val subtitle: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val color: Color,
    val questions: List<QuizQuestion>
)

enum class QuizState {
    Selecting,
    Playing,
    Results
}


// SCREEN 3: Milestone celebration Trophy screen with Falling Confetti Canvas drawing cycles
@Composable
fun MilestoneScreen(
    viewModel: StudyViewModel,
    onBackToPlanner: () -> Unit
) {
    val totalHours by viewModel.totalStudyHours.collectAsState()
    val completedCourses by viewModel.completedCourses.collectAsState()
    val streakCount by viewModel.dayStreak.collectAsState()

    // Confetti particles generator states represented with floats
    val particles = remember {
        List(40) {
            ConfettiParticle(
                x = Random.nextFloat(),
                y = Random.nextFloat() * -500f,
                speed = Random.nextFloat() * 4f + 3f,
                size = Random.nextFloat() * 12f + 8f,
                color = listOf(Color(0xFF4A90D9), Color(0xFF52C77A), Color(0xFFFFD700), Color(0xFFFF6B6B)).random(),
                rotationSpeed = Random.nextFloat() * 5f + 2f
            )
        }
    }

    // Ticking Anim loop
    val infiniteTransition = rememberInfiniteTransition(label = "confetti")
    val ticker by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1000f,
        animationSpec = infiniteRepeatable(
            animation = tween(10000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "tick"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0xFFFDFCFF), Color(0xFFF8F9FC))
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        // Draw falling confettis on canvas
        Canvas(modifier = Modifier.fillMaxSize()) {
            particles.forEach { p ->
                val elapsed = ticker // Ticking force
                val currentY = (p.y + (elapsed * p.speed)) % size.height
                val currentX = (p.x * size.width)
                drawRect(
                    color = p.color,
                    topLeft = Offset(currentX, currentY),
                    size = androidx.compose.ui.geometry.Size(p.size, p.size)
                )
            }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Milestone top capsule header
            Spacer(modifier = Modifier.height(24.dp))

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Vector Trophy representation
                Box(
                    modifier = Modifier
                        .size(140.dp)
                        .scale(1.1f)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Star,
                        tint = MaterialTheme.colorScheme.secondary,
                        contentDescription = "Trophy Milestone",
                        modifier = Modifier.size(90.dp)
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(99.dp))
                        .background(MaterialTheme.colorScheme.primaryContainer)
                        .padding(horizontal = 14.dp, vertical = 6.dp)
                ) {
                    Text(
                        "JALON ATTEINT !",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                }

                Text(
                    text = "Vous êtes un Maître de l'Étude !",
                    style = MaterialTheme.typography.headlineLarge,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = "Vous avez consacré de nombreuses heures d'apprentissage à élargir vos horizons. Progrès incroyables !",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 12.dp)
                )
            }

            // High rounded stats card
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                    elevation = CardDefaults.cardElevation(2.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "100",
                            style = MaterialTheme.typography.displayLarge.copy(
                                fontSize = 32.sp,
                                fontWeight = FontWeight.ExtraBold
                            ),
                            color = MaterialTheme.colorScheme.secondary
                        )
                        Text(
                            "HEURES TOTALES",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                    elevation = CardDefaults.cardElevation(2.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "$streakCount",
                            style = MaterialTheme.typography.displayLarge.copy(
                                fontSize = 32.sp,
                                fontWeight = FontWeight.ExtraBold
                            ),
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            "JOURS CONSÉCUTIFS",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // CTAs share and back
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Button(
                    onClick = { viewModel.triggerToast("Lien de partage copié !") },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                    shape = RoundedCornerShape(99.dp),
                    modifier = Modifier.fillMaxWidth(),
                    contentPadding = PaddingValues(vertical = 14.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.Share, contentDescription = "Share", tint = MaterialTheme.colorScheme.onSecondary)
                        Text("Partager ma réussite", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSecondary)
                    }
                }

                TextButton(
                    onClick = onBackToPlanner,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        "Retour aux tâches",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }
    }
}

class ConfettiParticle(
    val x: Float,
    val y: Float,
    val speed: Float,
    val size: Float,
    val color: Color,
    val rotationSpeed: Float
)


// SCREEN 4: Recharge Break Screen (Pomodoro break)
@Composable
fun RechargeBreakScreen(
    viewModel: StudyViewModel,
    onSkipBreak: () -> Unit
) {
    val secSLeft by viewModel.timerSecondsLeft.collectAsState()
    val isRunning by viewModel.timerIsRunning.collectAsState()
    val isBreakMode by viewModel.timerIsBreakMode.collectAsState()

    // Match original total duration for progress metering
    var totalSecondsPreset by remember { mutableStateOf(1500) }

    // Keep totalSecondsPreset in sync if state moves to break mode
    LaunchedEffect(isBreakMode) {
        if (isBreakMode) {
            totalSecondsPreset = 300
        } else if (totalSecondsPreset == 300) {
            totalSecondsPreset = 1500
        }
    }

    val maxSeconds = if (isBreakMode) 300 else totalSecondsPreset
    val progressFraction = if (maxSeconds > 0) {
        (secSLeft.toFloat() / maxSeconds.toFloat()).coerceIn(0f, 1f)
    } else {
        1f
    }

    val minutes = secSLeft / 60
    val seconds = secSLeft % 60
    val timerString = String.format("%02d:%02d", minutes, seconds)

    // Gentle sizing pulse when ticking
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val textScale by if (isRunning) {
        infiniteTransition.animateFloat(
            initialValue = 0.97f,
            targetValue = 1.03f,
            animationSpec = infiniteRepeatable(
                animation = tween(1200, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "timerPulse"
        )
    } else {
        remember { mutableStateOf(1.0f) }
    }

    val modeColor = if (isBreakMode) {
        MaterialTheme.colorScheme.secondary
    } else {
        MaterialTheme.colorScheme.primary
    }

    val modeContainerColor = if (isBreakMode) {
        MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.2f)
    } else {
        MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.2f)
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = MaterialTheme.colorScheme.background
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Header topbar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onSkipBreak,
                    modifier = Modifier.background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f), CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Retour",
                        tint = MaterialTheme.colorScheme.onSurface
                    )
                }
                Spacer(modifier = Modifier.weight(1f))
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(99.dp))
                        .background(modeContainerColor)
                        .padding(horizontal = 14.dp, vertical = 6.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(modeColor)
                        )
                        Text(
                            text = if (isBreakMode) "MODE PAUSE" else "MODE FOCUS",
                            style = MaterialTheme.typography.labelMedium,
                            color = modeColor,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    }
                }
                Spacer(modifier = Modifier.weight(1.3f))
            }

            // Circular Countdown Area
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(280.dp)
                        .padding(8.dp)
                ) {
                    // Circular outer visual tracks
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        drawCircle(
                            color = modeColor.copy(alpha = 0.1f),
                            style = Stroke(width = 12.dp.toPx())
                        )
                        drawArc(
                            color = modeColor,
                            startAngle = -90f,
                            sweepAngle = 360f * progressFraction,
                            useCenter = false,
                            style = Stroke(
                                width = 12.dp.toPx(),
                                cap = StrokeCap.Round
                            )
                        )
                    }

                    // Numeric clock and quick adjustments
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                        modifier = Modifier.graphicsLayer {
                            scaleX = textScale
                            scaleY = textScale
                        }
                    ) {
                        Icon(
                            imageVector = if (isBreakMode) Icons.Default.Info else Icons.Default.Schedule,
                            contentDescription = null,
                            tint = modeColor,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = timerString,
                            style = MaterialTheme.typography.displayLarge.copy(
                                fontSize = 56.sp,
                                fontWeight = FontWeight.Bold
                            ),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = if (isBreakMode) "Détente" else "Travail intensif",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontWeight = FontWeight.Medium
                        )

                        Spacer(modifier = Modifier.height(12.dp))
                        // Real-time minute adding/subtracting buttons (+1 min, -1 min)
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(
                                onClick = {
                                    if (!isBreakMode) {
                                        val newSec = (secSLeft - 60).coerceAtLeast(60)
                                        totalSecondsPreset = newSec
                                        viewModel.resetTimer(newSec)
                                    } else {
                                        val newSec = (secSLeft - 60).coerceAtLeast(60)
                                        viewModel.resetTimer(newSec)
                                    }
                                },
                                modifier = Modifier
                                    .size(36.dp)
                                    .border(1.dp, modeColor.copy(alpha = 0.3f), CircleShape)
                            ) {
                                Text("-1m", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = modeColor)
                            }

                            IconButton(
                                onClick = {
                                    if (!isBreakMode) {
                                        val newSec = (secSLeft + 60).coerceAtMost(7200)
                                        totalSecondsPreset = newSec
                                        viewModel.resetTimer(newSec)
                                    } else {
                                        val newSec = (secSLeft + 60).coerceAtMost(1800)
                                        viewModel.resetTimer(newSec)
                                    }
                                },
                                modifier = Modifier
                                    .size(36.dp)
                                    .border(1.dp, modeColor.copy(alpha = 0.3f), CircleShape)
                            ) {
                                Text("+1m", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = modeColor)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Presets controls to easily choose 15, 25 or 45 mins focus
                AnimatedVisibility(
                    visible = !isRunning,
                    enter = fadeIn() + expandVertically(),
                    exit = fadeOut() + shrinkVertically()
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "Ajustement rapide du focus",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            listOf(
                                Pair("15 Min", 900),
                                Pair("25 Min", 1500),
                                Pair("45 Min", 2700)
                            ).forEach { preset ->
                                val isSelected = totalSecondsPreset == preset.second && !isBreakMode
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(99.dp))
                                        .background(if (isSelected) modeColor else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                                        .clickable {
                                            totalSecondsPreset = preset.second
                                            viewModel.resetTimer(preset.second)
                                        }
                                        .padding(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Text(
                                        text = preset.first,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Bottom controls section (Tips and Actions)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                // Recovery exercises block (Image 6)
                if (isBreakMode) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "Exercices de récupération rapide",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        
                        // Exercise 1: Deep Breathing
                        Card(
                            onClick = { viewModel.triggerToast("Faites de grandes inspirations lentes...") },
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                            modifier = Modifier.fillMaxWidth().border(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f), RoundedCornerShape(16.dp))
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .background(Color(0xFFE8F8EF), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.Spa, contentDescription = null, tint = Color(0xFF2E7D32))
                                }
                                Column {
                                    Text("Défi Respiration Profonde", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                                    Text("Améliorez l'oxygénation de vos poumons et votre calme.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }

                        // Exercise 2: Eye Yoga
                        Card(
                            onClick = { viewModel.triggerToast("Détendez vos mirettes pendant 1 minute...") },
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                            modifier = Modifier.fillMaxWidth().border(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f), RoundedCornerShape(16.dp))
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .background(Color(0xFFE8F1FF), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.Visibility, contentDescription = null, tint = Color(0xFF005EDA))
                                }
                                Column {
                                    Text("Yoga des Yeux", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                                    Text("Détendez et étirez vos muscles oculaires pour éviter la fatigue.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                } else {
                    // Tip Card for focus mode
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = modeColor.copy(alpha = 0.05f)
                        )
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Star,
                                contentDescription = null,
                                tint = modeColor
                            )
                            Text(
                                text = "Éloignez vos distractions et restez concentré. Chaque minute de focus apporte sa réussite.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }

                // Core play controls
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Reset
                    IconButton(
                        onClick = {
                            if (isBreakMode) {
                                viewModel.resetTimer(300)
                            } else {
                                viewModel.resetTimer(totalSecondsPreset)
                            }
                            viewModel.triggerToast("Minuteur réinitialisé !")
                        },
                        modifier = Modifier
                            .size(56.dp)
                            .background(
                                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                CircleShape
                            )
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Restart",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    // Main Start/Pause FAB
                    FloatingActionButton(
                        onClick = {
                            if (isRunning) {
                                viewModel.pauseTimer()
                            } else {
                                viewModel.startTimer()
                            }
                        },
                        containerColor = modeColor,
                        contentColor = Color.White,
                        shape = CircleShape,
                        modifier = Modifier.size(72.dp),
                        elevation = FloatingActionButtonDefaults.elevation(8.dp)
                    ) {
                        Icon(
                            imageVector = if (isRunning) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = if (isRunning) "Pause" else "Play",
                            modifier = Modifier.size(36.dp)
                        )
                    }

                    // Skip Phase
                    IconButton(
                        onClick = {
                            if (isBreakMode) {
                                onSkipBreak()
                            } else {
                                viewModel.pauseTimer()
                                viewModel.resetTimer(300)
                                viewModel.startTimer()
                                viewModel.triggerToast("Lancement de la pause !")
                            }
                        },
                        modifier = Modifier
                            .size(56.dp)
                            .background(
                                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                CircleShape
                            )
                    ) {
                        Icon(
                            imageVector = Icons.Default.SkipNext,
                            contentDescription = "Skip",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
                
                Spacer(modifier = Modifier.height(20.dp))
                
                // Acceleration Test trigger to experience notifications without waiting minutes
                Button(
                    onClick = {
                        viewModel.resetTimer(1)
                        viewModel.startTimer()
                        viewModel.triggerToast("Minuteur réglé à 1 seconde...")
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = modeColor.copy(alpha = 0.12f),
                        contentColor = modeColor
                    ),
                    shape = RoundedCornerShape(99.dp),
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayCircle,
                        contentDescription = "Fast trigger",
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Simuler la Fin (1s)",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.labelLarge
                    )
                }
            }
        }
    }
}
