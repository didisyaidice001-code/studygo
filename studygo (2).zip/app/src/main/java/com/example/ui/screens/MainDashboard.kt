package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Task
import com.example.ui.theme.*
import com.example.ui.viewmodel.StudyViewModel
import androidx.compose.foundation.BorderStroke
import androidx.compose.ui.draw.rotate
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.PointerEventType
import androidx.compose.ui.draw.drawBehind
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.Spring

// Reusable Beautiful Vector Logo matching the user's StudyGo logo image
@Composable
fun StudyGoLogo(
    modifier: Modifier = Modifier,
    scale: Float = 1.0f,
    darkTheme: Boolean = true
) {
    Box(
        modifier = modifier
            .scale(scale)
            .wrapContentSize(),
        contentAlignment = Alignment.CenterStart
    ) {
        Row(
            verticalAlignment = Alignment.Bottom,
            modifier = Modifier.padding(top = 10.dp)
        ) {
            Text(
                text = "STUDY",
                color = if (darkTheme) Color(0xFF111111) else Color.White,
                fontSize = 28.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = (-1.5).sp,
                style = MaterialTheme.typography.displayMedium.copy(
                    fontFamily = androidx.compose.ui.text.font.FontFamily.SansSerif
                )
            )
        }
        
        Row(
            modifier = Modifier
                .offset(x = 74.dp, y = (-2).dp),
            horizontalArrangement = Arrangement.spacedBy((-1).dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(16.dp)
                    .background(Color(0xFF005EDA), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "G",
                    color = Color.White,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Black,
                    style = MaterialTheme.typography.labelSmall
                )
            }
            Box(
                modifier = Modifier
                    .size(16.dp)
                    .background(Color(0xFF005EDA), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "o",
                    color = Color.White,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Black,
                    style = MaterialTheme.typography.labelSmall
                )
            }
        }
    }
}

// Global Top Bar
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudyTopAppBar(
    title: String,
    onSearchClick: () -> Unit,
    onNotificationsClick: () -> Unit,
    onMenuClick: () -> Unit
) {
    TopAppBar(
        title = {
            Box(modifier = Modifier.padding(start = 4.dp)) {
                StudyGoLogo(
                    scale = 0.9f,
                    darkTheme = true
                )
            }
        },
        actions = {
            IconButton(onClick = onSearchClick) {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = "Search notes",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            IconButton(onClick = onNotificationsClick) {
                Icon(
                    imageVector = Icons.Default.Notifications,
                    contentDescription = "Notifications",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            IconButton(onClick = onMenuClick) {
                Icon(
                    imageVector = Icons.Default.Menu,
                    contentDescription = "Menu drawer",
                    tint = MaterialTheme.colorScheme.primary
                )
            }
        },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = MaterialTheme.colorScheme.surface,
            titleContentColor = MaterialTheme.colorScheme.primary
        )
    )
}

// Reusable Bottom Bar custom matching beautiful UI
@Composable
fun StudyBottomBar(
    currentTab: String,
    onTabSelected: (String) -> Unit
) {
    val items = listOf(
        NavigationItemData("home", "Accueil", Icons.Default.Home),
        NavigationItemData("explore", "Explorer", Icons.Default.Explore),
        NavigationItemData("planner", "Tâches", Icons.Default.EventNote),
        NavigationItemData("progress", "Progrès", Icons.Default.Star),
        NavigationItemData("profile", "Profil", Icons.Default.Person)
    )

    // Floating Capsule Container with bottom margin to respect edge-to-edge layout & system gestures
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .windowInsetsPadding(WindowInsets.navigationBars)
            .padding(horizontal = 20.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Card(
            shape = RoundedCornerShape(99.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceContainerLowest.copy(alpha = 0.96f)
            ),
            elevation = CardDefaults.cardElevation(defaultElevation = 10.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(
                    width = 1.dp,
                    color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f),
                    shape = RoundedCornerShape(99.dp)
                )
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                items.forEach { item ->
                    val isSelected = currentTab == item.id
                    
                    val animatedScale by animateFloatAsState(
                        targetValue = if (isSelected) 1.15f else 1.0f,
                        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
                        label = "iconScale"
                    )
                    
                    val activeColor = MaterialTheme.colorScheme.primary
                    val inactiveColor = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                    
                    val tintColor by animateColorAsState(
                        targetValue = if (isSelected) activeColor else inactiveColor,
                        label = "iconColor"
                    )

                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(99.dp))
                            .clickable { onTabSelected(item.id) }
                            .padding(vertical = 4.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        // Floating elegant bar indicator above selected tab (Design 1)
                        Box(
                            modifier = Modifier
                                .height(3.dp)
                                .width(24.dp)
                                .clip(RoundedCornerShape(99.dp))
                                .background(if (isSelected) activeColor else Color.Transparent)
                        )
                        
                        Spacer(modifier = Modifier.height(4.dp))

                        Icon(
                            imageVector = item.icon,
                            contentDescription = item.title,
                            tint = tintColor,
                            modifier = Modifier
                                .size(24.dp)
                                .scale(animatedScale)
                        )
                        
                        Spacer(modifier = Modifier.height(2.dp))
                        
                        Text(
                            text = item.title,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                fontSize = 10.sp
                            ),
                            color = tintColor
                        )
                    }
                }
            }
        }
    }
}

data class NavigationItemData(
    val id: String,
    val title: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector
)

// TAB 1: Home Dashboard Screen
@Composable
fun DashboardScreen(
    viewModel: StudyViewModel,
    onTabSelected: (String) -> Unit,
    onSubjectClick: (String) -> Unit,
    onLaunchPomodoro: () -> Unit
) {
    val tasks by viewModel.tasks.collectAsState()
    val completedHours by viewModel.totalStudyHours.collectAsState()

    val completedTasks = tasks.filter { it.isCompleted }
    val progressPercentage = if (tasks.isNotEmpty()) {
        (completedTasks.size.toFloat() / tasks.size.toFloat()) * 100
    } else {
        50f
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        // Welcome and intro
        item {
            Column(modifier = Modifier.padding(top = 16.dp)) {
                Text(
                    text = "Bonjour, Alex",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "Atteignons vos objectifs !",
                    style = MaterialTheme.typography.headlineLarge,
                    color = MaterialTheme.colorScheme.onSurface,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Animated Quote & Illustration Card
        item {
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        1.dp,
                        MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f),
                        RoundedCornerShape(24.dp)
                    ),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Serene Quote flat drawing representation
                    Box(
                        modifier = Modifier
                            .size(120.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.05f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.School,
                            contentDescription = "Reading student graphic representation",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(64.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "\"The expert in anything was once a beginner.\"",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.SemiBold,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "— Helen Hayes",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Today's Focus Card (Level 1)
        item {
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        1.dp,
                        MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f),
                        RoundedCornerShape(24.dp)
                    ),
                elevation = CardDefaults.cardElevation(4.dp)
            ) {
                Column(modifier = Modifier.padding(24.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Column {
                            Text(
                                text = "Objectif du jour",
                                style = MaterialTheme.typography.titleLarge,
                                color = MaterialTheme.colorScheme.onSurface,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Concentration quotidienne",
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(99.dp))
                                .background(MaterialTheme.colorScheme.secondaryContainer)
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = "${progressPercentage.toInt()}% Terminé",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSecondaryContainer,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    // Thick rounded progress indicators
                    LinearProgressIndicator(
                        progress = { progressPercentage / 100f },
                        color = MaterialTheme.colorScheme.secondary,
                        trackColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(14.dp)
                            .clip(CircleShape)
                    )

                    Spacer(modifier = Modifier.height(18.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy((-6).dp)) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .background(PrimaryFixed, CircleShape)
                                    .border(2.dp, Color.White, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    "MA",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = OnPrimaryFixed
                                )
                            }
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .background(SecondaryFixedDim, CircleShape)
                                    .border(2.dp, Color.White, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    "SC",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = OnSecondaryFixedVariant
                                )
                            }
                        }
                        Text(
                            text = "${completedTasks.size}/${tasks.size} tâches terminées",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }

        // Pomodoro Quick Access Entry
        item {
            Card(
                onClick = onLaunchPomodoro,
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary),
                modifier = Modifier.fillMaxWidth(),
                elevation = CardDefaults.cardElevation(2.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color.White.copy(alpha = 0.2f))
                                .padding(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Schedule,
                                contentDescription = "Active Timer",
                                tint = Color.White,
                                modifier = Modifier.size(28.dp)
                            )
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Pomodoro",
                                style = MaterialTheme.typography.titleLarge,
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Prêt à commencer ? Session de 25 min",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.White.copy(alpha = 0.85f),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = onLaunchPomodoro,
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                        shape = RoundedCornerShape(99.dp),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                        modifier = Modifier.height(40.dp)
                    ) {
                        Text(
                            text = "Démarrer",
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            softWrap = false
                        )
                    }
                }
            }
        }

        // Custom categories chips row
        item {
            Column(modifier = Modifier.padding(bottom = 24.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Matières Actuelles",
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.onSurface,
                        fontWeight = FontWeight.Bold
                    )
                    TextButton(onClick = { onSubjectClick("Mathematics") }) {
                        Text("Voir Tout", color = MaterialTheme.colorScheme.primary)
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item {
                        SubjectInteractiveChip(
                            title = "Advanced Calculus",
                            color = MaterialTheme.colorScheme.primary,
                            bgColor = PrimaryFixed,
                            textColor = OnPrimaryFixed,
                            onClick = { onSubjectClick("Mathematics") }
                        )
                    }
                    item {
                        SubjectInteractiveChip(
                            title = "Macroeconomics",
                            color = MaterialTheme.colorScheme.secondary,
                            bgColor = SecondaryFixed,
                            textColor = OnSecondaryFixedVariant,
                            onClick = { onSubjectClick("Mathematics") }
                        )
                    }
                    item {
                        SubjectInteractiveChip(
                            title = "World History",
                            color = MaterialTheme.colorScheme.tertiary,
                            bgColor = TertiaryFixed,
                            textColor = OnTertiaryFixed,
                            onClick = { onSubjectClick("Mathematics") }
                        )
                    }
                }
            }
        }

        // Section Récompenses & Progression système
        item {
            var selectedBadgeIndex by remember { mutableStateOf(0) }
            val badgesList = listOf(
                Triple("Lève-tôt ☀️", "Compléter une session d'au moins 25 minutes de Pomodoro avant 8h00 du matin.", true),
                Triple("Série 7 jours 🔥", "Compléter au moins une tâche d'étude planifiée par jour pendant une semaine.", true),
                Triple("Maître Math 📐", "Obtenir un score parfait (100% de bonnes réponses) à un quiz de Mathématiques.", false),
                Triple("Concentration Pro 🧠", "Cumuler un total de 10 sessions complètes du minuteur Pomodoro.", false)
            )
            val badgeIcons = listOf(
                Icons.Default.Star,
                Icons.Default.Favorite,
                Icons.Default.School,
                Icons.Default.Schedule
            )
            val badgeColors = listOf(
                Color(0xFFFBBF24), // Gold Yellow
                Color(0xFFEF4444), // Warm Red
                Color(0xFF3B82F6), // Bleu StudyGo
                Color(0xFF8B5CF6)  // Purple
            )

            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 20.dp)
                    .border(
                        1.dp,
                        MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f),
                        RoundedCornerShape(24.dp)
                    ),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Header row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                "🏆",
                                fontSize = 22.sp
                            )
                            Column {
                                Text(
                                    text = "Mes Récompenses",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "Survolez ou touchez un badge pour l'explorer",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(99.dp))
                                .background(MaterialTheme.colorScheme.secondaryContainer)
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "2/4 Débloqués",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSecondaryContainer
                            )
                        }
                    }

                    // Interactive progress bar
                    LinearProgressIndicator(
                        progress = { 0.5f },
                        color = MaterialTheme.colorScheme.secondary,
                        trackColor = MaterialTheme.colorScheme.surfaceContainer,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(CircleShape)
                    )

                    // Bouncy animated arrow math offset
                    val animatedIndex by animateFloatAsState(
                        targetValue = selectedBadgeIndex.toFloat(),
                        animationSpec = spring(dampingRatio = Spring.DampingRatioLowBouncy, stiffness = Spring.StiffnessMedium),
                        label = "arrowIndex"
                    )

                    val tooltipBgColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.85f)
                    
                    // Tooltip box pointing down
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .drawBehind {
                                val colWidth = size.width / 4f
                                val arrowX = colWidth * animatedIndex + (colWidth / 2f)
                                val path = Path().apply {
                                    moveTo(arrowX - 10.dp.toPx(), size.height)
                                    lineTo(arrowX, size.height + 8.dp.toPx())
                                    lineTo(arrowX + 10.dp.toPx(), size.height)
                                    close()
                                }
                                drawPath(path, color = tooltipBgColor)
                            }
                            .background(tooltipBgColor, RoundedCornerShape(16.dp))
                            .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.15f), RoundedCornerShape(16.dp))
                            .padding(14.dp)
                    ) {
                        val currentBadge = badgesList[selectedBadgeIndex]
                        val isUnlocked = currentBadge.third
                        
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = currentBadge.first,
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                                
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(99.dp))
                                        .background(if (isUnlocked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                                        .padding(horizontal = 8.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = if (isUnlocked) "Débloqué 🎉" else "Verrouillé 🔒",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isUnlocked) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            
                            Text(
                                text = currentBadge.second,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.85f)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp)) // subtle pad for the triangle pointing down

                    // Badges Grid row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        badgesList.forEachIndexed { index, item ->
                            val isSelected = selectedBadgeIndex == index
                            val isUnlocked = item.third
                            val badgeColor = badgeColors[index]
                            
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable { selectedBadgeIndex = index }
                                    .pointerInput(index) {
                                        awaitPointerEventScope {
                                            while (true) {
                                                val event = awaitPointerEvent()
                                                if (event.type == PointerEventType.Enter) {
                                                    selectedBadgeIndex = index
                                                }
                                            }
                                        }
                                    }
                                    .padding(vertical = 4.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(60.dp)
                                        .clip(CircleShape)
                                        .background(
                                            if (isUnlocked) badgeColor.copy(alpha = 0.15f) 
                                            else MaterialTheme.colorScheme.surfaceContainerHighest.copy(alpha = 0.6f)
                                        )
                                        .border(
                                            width = if (isSelected) 2.5.dp else 1.5.dp,
                                            color = if (isSelected) badgeColor 
                                                    else if (isUnlocked) badgeColor.copy(alpha = 0.4f) 
                                                    else MaterialTheme.colorScheme.outlineVariant,
                                            shape = CircleShape
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = if (isUnlocked) badgeIcons[index] else Icons.Default.Lock,
                                        tint = if (isUnlocked) badgeColor else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
                                        contentDescription = item.first,
                                        modifier = Modifier.size(if (isUnlocked) 28.dp else 22.dp)
                                    )
                                }
                                
                                Text(
                                    text = item.first.substringBefore(" "),
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) MaterialTheme.colorScheme.onSurface 
                                            else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SubjectInteractiveChip(
    title: String,
    color: Color,
    bgColor: Color,
    textColor: Color,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(99.dp))
            .background(bgColor)
            .border(1.dp, color.copy(alpha = 0.2f), RoundedCornerShape(99.dp))
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .background(color, CircleShape)
            )
            Text(
                title,
                style = MaterialTheme.typography.labelLarge,
                color = textColor,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}


// TAB 2: Planner (Mes Tâches) Database-driven list with integrated browser-style HashRouter
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlannerScreen(
    viewModel: StudyViewModel,
    onAddTaskClick: () -> Unit
) {
    val tasks by viewModel.tasks.collectAsState()

    // 1. Manage state-based SPA router matching "HashRouter"
    var currentRoute by remember { mutableStateOf("#/all") }
    
    // Physical routing history to support browser Back and Forward history!
    val historyStack = remember { mutableStateListOf("#/all") }
    var historyIndex by remember { mutableStateOf(0) }

    // Helper to navigate
    val navigateTo: (String) -> Unit = { route ->
        if (historyIndex < historyStack.size - 1) {
            val toRemove = historyStack.size - 1 - historyIndex
            repeat(toRemove) {
                historyStack.removeAt(historyStack.size - 1)
            }
        }
        if (historyStack.lastOrNull() != route) {
            historyStack.add(route)
        }
        historyIndex = historyStack.size - 1
        currentRoute = route
    }

    val navigateBack: () -> Unit = {
        if (historyIndex > 0) {
            historyIndex--
            currentRoute = historyStack[historyIndex]
        }
    }

    val navigateForward: () -> Unit = {
        if (historyIndex < historyStack.size - 1) {
            historyIndex++
            currentRoute = historyStack[historyIndex]
        }
    }

    // Refresh simulation effect
    var isRefreshing by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val rotationAngle by animateFloatAsState(
        targetValue = if (isRefreshing) 360f else 0f,
        animationSpec = if (isRefreshing) infiniteRepeatable(
            animation = tween(1000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ) else tween(0),
        label = "refreshRotation"
    )

    fun triggerRefresh() {
        if (!isRefreshing) {
            isRefreshing = true
            scope.launch {
                delay(750)
                isRefreshing = false
                viewModel.triggerToast("Données synchronisées via HashRouter local !")
            }
        }
    }

    Scaffold(
        floatingActionButton = {
            if (currentRoute == "#/all") {
                FloatingActionButton(
                    onClick = { navigateTo("#/new") },
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Nouvelle tâche",
                        modifier = Modifier.size(32.dp)
                    )
                }
            }
        },
        containerColor = Color.Transparent
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Header
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = PrimaryFixed.copy(alpha = 0.15f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 12.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Gestionnaire d'Études",
                            style = MaterialTheme.typography.titleLarge,
                            color = OnPrimaryFixed,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Gérez vos priorités avec HashRouter SPA",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Icon(
                        imageVector = Icons.Default.Info,
                        tint = MaterialTheme.colorScheme.primary,
                        contentDescription = "Router illustration",
                        modifier = Modifier.size(40.dp)
                    )
                }
            }

            // 2. Browser address-bar simulator interface representing client-side HashRouter!
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    // Browser control row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Back Button
                        IconButton(
                            onClick = navigateBack,
                            enabled = historyIndex > 0,
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.ArrowBack,
                                contentDescription = "Back history",
                                tint = if (historyIndex > 0) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        // Forward Button
                        IconButton(
                            onClick = navigateForward,
                            enabled = historyIndex < historyStack.size - 1,
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.ArrowForward,
                                contentDescription = "Forward history",
                                tint = if (historyIndex < historyStack.size - 1) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        // Refresh/Spin Button
                        IconButton(
                            onClick = { triggerRefresh() },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Reload HashRouter",
                                tint = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier
                                    .size(20.dp)
                                    .rotate(rotationAngle)
                            )
                        }

                        // Address Bar Field
                        Row(
                            modifier = Modifier
                                .weight(1f)
                                .height(38.dp)
                                .clip(RoundedCornerShape(99.dp))
                                .background(MaterialTheme.colorScheme.surfaceContainerLowest)
                                .border(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.2f), RoundedCornerShape(99.dp))
                                .padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = "Secure connection",
                                tint = Color(0xFF2E7D32),
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = "studygo://planner/",
                                color = MaterialTheme.colorScheme.outline,
                                style = MaterialTheme.typography.bodySmall,
                                maxLines = 1
                            )
                            Text(
                                text = currentRoute,
                                color = MaterialTheme.colorScheme.primary,
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1
                            )
                        }
                    }

                    // Direct route chips
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        listOf(
                            Pair("#/all", "Liste"),
                            Pair("#/calendar", "Calendrier"),
                            Pair("#/new", "Ajouter"),
                            Pair("#/stats", "Stats")
                        ).forEach { routePair ->
                            val isSelected = currentRoute == routePair.first || (routePair.first == "#/all" && currentRoute.startsWith("#/details"))
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceContainerLowest)
                                    .clickable { navigateTo(routePair.first) }
                                    .padding(vertical = 6.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = routePair.second,
                                    color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }

            // 3. Render Simulated HashRouter Route Container with Animated SPA Transitions (slow, upward, 600ms)
            AnimatedContent(
                targetState = currentRoute,
                transitionSpec = {
                    slideInVertically(
                        animationSpec = tween(600, easing = FastOutSlowInEasing),
                        initialOffsetY = { it }
                    ) + fadeIn(animationSpec = tween(600)) togetherWith
                            slideOutVertically(
                                animationSpec = tween(600, easing = FastOutSlowInEasing),
                                targetOffsetY = { -it }
                            ) + fadeOut(animationSpec = tween(600))
                },
                label = "HashRouterView",
                modifier = Modifier.weight(1f)
            ) { routeState ->
                if (isRefreshing) {
                    // Refresh overlay block
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                    }
                } else when {
                    // --- ROUTE: #/all ---
                    routeState == "#/all" -> {
                        var searchQuery by remember { mutableStateOf("") }
                        var selectedFilter by remember { mutableStateOf("All") } // "All", "Todo", "Today", "Completed"

                        val filteredTasks = tasks.filter { task ->
                            // Title search match
                            val matchesSearch = task.title.lowercase().contains(searchQuery.lowercase())
                            // State filters
                            val matchesFilter = when (selectedFilter) {
                                "Todo" -> !task.isCompleted
                                "Completed" -> task.isCompleted
                                "Today" -> isSameDay(task.timestamp, System.currentTimeMillis())
                                else -> true
                            }
                            matchesSearch && matchesFilter
                        }

                        Column(
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            // Search Box
                            TextField(
                                value = searchQuery,
                                onValueChange = { searchQuery = it },
                                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Rechercher") },
                                trailingIcon = {
                                    if (searchQuery.isNotEmpty()) {
                                        IconButton(onClick = { searchQuery = "" }) {
                                            Icon(Icons.Default.Close, contentDescription = "Clear search")
                                        }
                                    }
                                },
                                placeholder = { Text("Rechercher une tâche d'étude...") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                shape = RoundedCornerShape(12.dp),
                                colors = TextFieldDefaults.colors(
                                    focusedContainerColor = MaterialTheme.colorScheme.surfaceContainerLowest,
                                    unfocusedContainerColor = MaterialTheme.colorScheme.surfaceContainerLowest,
                                    focusedIndicatorColor = Color.Transparent,
                                    unfocusedIndicatorColor = Color.Transparent
                                )
                            )

                            // Horizontal filter chips
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                listOf(
                                    Pair("All", "Tout"),
                                    Pair("Todo", "À faire"),
                                    Pair("Today", "Aujourd'hui"),
                                    Pair("Completed", "Terminé")
                                ).forEach { filterPair ->
                                    val isSelected = selectedFilter == filterPair.first
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clip(RoundedCornerShape(99.dp))
                                            .background(if (isSelected) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.surfaceContainerHigh)
                                            .clickable { selectedFilter = filterPair.first }
                                            .padding(vertical = 6.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = filterPair.second,
                                            color = if (isSelected) MaterialTheme.colorScheme.onSecondary else MaterialTheme.colorScheme.onSurfaceVariant,
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }

                            if (filteredTasks.isEmpty()) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .weight(1f),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Folder,
                                            contentDescription = "Empty",
                                            tint = MaterialTheme.colorScheme.outlineVariant,
                                            modifier = Modifier.size(56.dp)
                                        )
                                        Text(
                                            text = "Aucune tâche correspondante.",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.outline
                                        )
                                    }
                                }
                            } else {
                                LazyColumn(
                                    modifier = Modifier.fillMaxSize(),
                                    verticalArrangement = Arrangement.spacedBy(10.dp),
                                    contentPadding = PaddingValues(bottom = 72.dp)
                                ) {
                                    items(filteredTasks, key = { it.id }) { task ->
                                        Box(
                                            modifier = Modifier.clickable { navigateTo("#/details/${task.id}") }
                                        ) {
                                            TaskItemCard(
                                                task = task,
                                                onToggleCompletion = { viewModel.toggleTaskCompletion(task) },
                                                onDelete = { viewModel.deleteTask(task) }
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // --- ROUTE: #/calendar ---
                    routeState == "#/calendar" -> {
                        val selectedDate by viewModel.selectedCalendarDate.collectAsState()
                        
                        Column(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            MonthlyCalendarView(
                                viewModel = viewModel,
                                tasks = tasks,
                                selectedDate = selectedDate,
                                onDateSelected = { viewModel.selectedCalendarDate.value = it }
                            )

                            val sdf = remember { java.text.SimpleDateFormat("EEEE d MMMM", java.util.Locale.FRANCE) }
                            val formattedDate = sdf.format(java.util.Date(selectedDate))
                            
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = formattedDate.replaceFirstChar { if (it.isLowerCase()) it.titlecase(java.util.Locale.FRANCE) else it.toString() },
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                TextButton(
                                    onClick = { navigateTo("#/new") }
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Planifier", style = MaterialTheme.typography.labelMedium)
                                }
                            }

                            val dayTasks = tasks.filter { isSameDay(it.timestamp, selectedDate) }

                            if (dayTasks.isEmpty()) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .weight(1f),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "Aucune échéance d'étude planifiée ce jour.",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.outline
                                    )
                                }
                            } else {
                                LazyColumn(
                                    modifier = Modifier.weight(1f),
                                    verticalArrangement = Arrangement.spacedBy(10.dp),
                                    contentPadding = PaddingValues(bottom = 72.dp)
                                ) {
                                    items(dayTasks, key = { it.id }) { task ->
                                        Box(
                                            modifier = Modifier.clickable { navigateTo("#/details/${task.id}") }
                                        ) {
                                            TaskItemCard(
                                                task = task,
                                                onToggleCompletion = { viewModel.toggleTaskCompletion(task) },
                                                onDelete = { viewModel.deleteTask(task) }
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // --- ROUTE: #/new ---
                    routeState == "#/new" -> {
                        var titleText by remember { mutableStateOf("") }
                        var subjectText by remember { mutableStateOf("Mathématiques") }
                        var priorityText by remember { mutableStateOf("Moyen") } // "Élevé", "Moyen", "Faible"
                        var targetTimestamp by remember { mutableStateOf(viewModel.selectedCalendarDate.value) }

                        // Mini inline calendar collapsed by default
                        var showDatePickerInline by remember { mutableStateOf(false) }

                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(14.dp),
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(bottom = 16.dp)
                        ) {
                            item {
                                Text(
                                    "Créer une tâche d'étude",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }

                            item {
                                OutlinedTextField(
                                    value = titleText,
                                    onValueChange = { titleText = it },
                                    label = { Text("Titre de la tâche") },
                                    placeholder = { Text("Ex: Réviser Chapitre 1 d'Algèbre...") },
                                    modifier = Modifier.fillMaxWidth(),
                                    singleLine = true,
                                    shape = RoundedCornerShape(12.dp)
                                )
                            }

                            // Subject choice
                            item {
                                Text("Matière", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                                Spacer(modifier = Modifier.height(4.dp))
                                LazyRow(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    items(listOf("Mathématiques", "Sciences Physiques", "Histoire & Géographie", "Économie", "Littérature")) { sub ->
                                        val isSelected = subjectText == sub
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(99.dp))
                                                .background(if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceContainerHigh)
                                                .clickable { subjectText = sub }
                                                .padding(horizontal = 14.dp, vertical = 8.dp)
                                        ) {
                                            Text(
                                                text = sub,
                                                color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                                style = MaterialTheme.typography.labelMedium,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }
                            }

                            // Priority choice
                            item {
                                Text("Priorité de la tâche", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    listOf(
                                        Triple("Élevé", Color(0xFFD32F2F), "Haute priorité"),
                                        Triple("Moyen", Color(0xFFF57C00), "Priorité normale"),
                                        Triple("Faible", Color(0xFF1976D2), "Basse priorité")
                                    ).forEach { (prio, color, desc) ->
                                        val isSelected = priorityText == prio
                                        Box(
                                            modifier = Modifier
                                                .weight(1f)
                                                .clip(RoundedCornerShape(12.dp))
                                                .border(2.dp, if (isSelected) color else Color.Transparent, RoundedCornerShape(12.dp))
                                                .background(if (isSelected) color.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceContainerHigh)
                                                .clickable { priorityText = prio }
                                                .padding(10.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(8.dp)
                                                        .background(color, CircleShape)
                                                )
                                                Spacer(modifier = Modifier.height(4.dp))
                                                Text(
                                                    text = prio,
                                                    style = MaterialTheme.typography.labelLarge,
                                                    color = if (isSelected) color else MaterialTheme.colorScheme.onSurfaceVariant,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                        }
                                    }
                                }
                            }

                            // Date picker row
                            item {
                                val sdf = remember { java.text.SimpleDateFormat("EEEE d MMMM yyyy", java.util.Locale.FRANCE) }
                                val formattedDate = sdf.format(java.util.Date(targetTimestamp))

                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.2f))
                                        .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.1f), RoundedCornerShape(12.dp))
                                        .clickable { showDatePickerInline = !showDatePickerInline }
                                        .padding(14.dp)
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Icon(Icons.Default.DateRange, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text("Date d'Échéance", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                                            Text(
                                                formattedDate.replaceFirstChar { if (it.isLowerCase()) it.titlecase(java.util.Locale.FRANCE) else it.toString() },
                                                style = MaterialTheme.typography.bodyMedium,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.onSurface
                                            )
                                        }
                                        Icon(
                                            imageVector = if (showDatePickerInline) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.outline
                                        )
                                    }

                                    // Inline Date Quick Changer
                                    AnimatedVisibility(
                                        visible = showDatePickerInline,
                                        enter = expandVertically() + fadeIn(),
                                        exit = shrinkVertically() + fadeOut()
                                    ) {
                                        Column(modifier = Modifier.padding(top = 12.dp)) {
                                            Text(
                                                "Modifier la date d'échéance :",
                                                style = MaterialTheme.typography.labelMedium,
                                                color = MaterialTheme.colorScheme.outline,
                                                modifier = Modifier.padding(bottom = 6.dp)
                                            )
                                            // Provide day selectors for the current month
                                            val calendar = java.util.Calendar.getInstance()
                                            val currentDay = calendar.get(java.util.Calendar.DAY_OF_MONTH)
                                            val totalDays = calendar.getActualMaximum(java.util.Calendar.DAY_OF_MONTH)
                                            
                                            Row(
                                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                                                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                                            ) {
                                                // Scrollable indicators
                                                LazyRow(
                                                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                                                    modifier = Modifier.fillMaxWidth()
                                                ) {
                                                    items((1..totalDays).toList()) { d ->
                                                        val isSelectedDay = java.util.Calendar.getInstance().apply { timeInMillis = targetTimestamp }.get(java.util.Calendar.DAY_OF_MONTH) == d
                                                        Box(
                                                            modifier = Modifier
                                                                .size(34.dp)
                                                                .clip(RoundedCornerShape(8.dp))
                                                                .background(
                                                                    when {
                                                                        isSelectedDay -> MaterialTheme.colorScheme.primary
                                                                        d == currentDay -> MaterialTheme.colorScheme.primaryContainer
                                                                        else -> MaterialTheme.colorScheme.surfaceContainerHigh
                                                                    }
                                                                )
                                                                .clickable {
                                                                    val newCal = java.util.Calendar.getInstance().apply {
                                                                        timeInMillis = targetTimestamp
                                                                        set(java.util.Calendar.DAY_OF_MONTH, d)
                                                                    }
                                                                    targetTimestamp = newCal.timeInMillis
                                                                },
                                                            contentAlignment = Alignment.Center
                                                        ) {
                                                            Text(
                                                                text = d.toString(),
                                                                fontSize = 11.sp,
                                                                fontWeight = FontWeight.Bold,
                                                                color = if (isSelectedDay) Color.White else MaterialTheme.colorScheme.onSurface
                                                            )
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            // Submit Button
                            item {
                                Button(
                                    onClick = {
                                        if (titleText.isNotBlank()) {
                                            viewModel.addTask(titleText, subjectText, priorityText, targetTimestamp)
                                            navigateTo("#/all")
                                        } else {
                                            viewModel.triggerToast("Veuillez donner un titre à la tâche !")
                                        }
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(50.dp),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Icon(Icons.Default.Check, contentDescription = null)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Valider la Tâche d'Étude", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    // --- ROUTE: #/details/{id} ---
                    routeState.startsWith("#/details") -> {
                        val detailsPrefix = "#/details/"
                        val idStr = routeState.substring(detailsPrefix.length)
                        val taskId = idStr.toIntOrNull()
                        val selectedTask = tasks.find { it.id == taskId }

                        if (selectedTask == null) {
                            Box(
                                modifier = Modifier.fillMaxSize(),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Icon(Icons.Default.Error, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(48.dp))
                                    Text("Tâche d'étude introuvable ou supprimée.")
                                    Button(onClick = { navigateTo("#/all") }) {
                                        Text("Retour à la liste")
                                    }
                                }
                            }
                        } else {
                            var titleText by remember(selectedTask.id) { mutableStateOf(selectedTask.title) }
                            var subjectText by remember(selectedTask.id) { mutableStateOf(selectedTask.subject) }
                            var priorityText by remember(selectedTask.id) { mutableStateOf(selectedTask.priority) }
                            var targetTimestamp by remember(selectedTask.id) { mutableStateOf(selectedTask.timestamp) }
                            var showDatePickerInline by remember { mutableStateOf(false) }

                            LazyColumn(
                                verticalArrangement = Arrangement.spacedBy(14.dp),
                                modifier = Modifier.fillMaxSize()
                            ) {
                                item {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        IconButton(onClick = { navigateTo("#/all") }) {
                                            Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                                        }
                                        Text(
                                            "Aperçu et Modification",
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                }

                                item {
                                    OutlinedTextField(
                                        value = titleText,
                                        onValueChange = { titleText = it },
                                        label = { Text("Titre de la tâche") },
                                        modifier = Modifier.fillMaxWidth(),
                                        singleLine = true,
                                        shape = RoundedCornerShape(12.dp)
                                    )
                                }

                                // Subject selections
                                item {
                                    Text("Matière", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                                    Spacer(modifier = Modifier.height(4.dp))
                                    LazyRow(
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        items(listOf("Mathématiques", "Sciences Physiques", "Histoire & Géographie", "Économie", "Littérature")) { sub ->
                                            val isSelected = subjectText == sub
                                            Box(
                                                modifier = Modifier
                                                    .clip(RoundedCornerShape(99.dp))
                                                    .background(if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceContainerHigh)
                                                    .clickable { subjectText = sub }
                                                    .padding(horizontal = 14.dp, vertical = 8.dp)
                                            ) {
                                                Text(
                                                    text = sub,
                                                    color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                                    style = MaterialTheme.typography.labelMedium,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                        }
                                    }
                                }

                                // Priority Choices
                                item {
                                    Text("Priorité", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Row(
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        listOf(
                                            Triple("Élevé", Color(0xFFD32F2F), "Haute"),
                                            Triple("Moyen", Color(0xFFF57C00), "Moyenne"),
                                            Triple("Faible", Color(0xFF1976D2), "Basse")
                                        ).forEach { (prio, color, desc) ->
                                            val isSelected = priorityText == prio
                                            Box(
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .clip(RoundedCornerShape(12.dp))
                                                    .border(2.dp, if (isSelected) color else Color.Transparent, RoundedCornerShape(12.dp))
                                                    .background(if (isSelected) color.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceContainerHigh)
                                                    .clickable { priorityText = prio }
                                                    .padding(10.dp),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                                    Box(
                                                        modifier = Modifier
                                                            .size(8.dp)
                                                            .background(color, CircleShape)
                                                    )
                                                    Spacer(modifier = Modifier.height(4.dp))
                                                    Text(
                                                        text = prio,
                                                        style = MaterialTheme.typography.labelLarge,
                                                        color = if (isSelected) color else MaterialTheme.colorScheme.onSurfaceVariant,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }

                                // Date picker picker details
                                item {
                                    val sdf = remember { java.text.SimpleDateFormat("EEEE d MMMM yyyy", java.util.Locale.FRANCE) }
                                    val formattedDate = sdf.format(java.util.Date(targetTimestamp))

                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.2f))
                                            .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.1f), RoundedCornerShape(12.dp))
                                            .clickable { showDatePickerInline = !showDatePickerInline }
                                            .padding(14.dp)
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            Icon(Icons.Default.DateRange, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text("Date d'Échéance", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                                                Text(
                                                    formattedDate.replaceFirstChar { if (it.isLowerCase()) it.titlecase(java.util.Locale.FRANCE) else it.toString() },
                                                    style = MaterialTheme.typography.bodyMedium,
                                                    fontWeight = FontWeight.Bold,
                                                    color = MaterialTheme.colorScheme.onSurface
                                                )
                                            }
                                            Icon(
                                                imageVector = if (showDatePickerInline) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                                                contentDescription = null,
                                                tint = MaterialTheme.colorScheme.outline
                                            )
                                        }

                                        AnimatedVisibility(
                                            visible = showDatePickerInline,
                                            enter = expandVertically() + fadeIn(),
                                            exit = shrinkVertically() + fadeOut()
                                        ) {
                                            Column(modifier = Modifier.padding(top = 12.dp)) {
                                                Text(
                                                    "Modifier la date d'échéance :",
                                                    style = MaterialTheme.typography.labelMedium,
                                                    color = MaterialTheme.colorScheme.outline,
                                                    modifier = Modifier.padding(bottom = 6.dp)
                                                )
                                                val calendar = java.util.Calendar.getInstance()
                                                val currentDay = calendar.get(java.util.Calendar.DAY_OF_MONTH)
                                                val totalDays = calendar.getActualMaximum(java.util.Calendar.DAY_OF_MONTH)
                                                
                                                LazyRow(
                                                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                                                    modifier = Modifier.fillMaxWidth()
                                                ) {
                                                    items((1..totalDays).toList()) { d ->
                                                        val isSelectedDay = java.util.Calendar.getInstance().apply { timeInMillis = targetTimestamp }.get(java.util.Calendar.DAY_OF_MONTH) == d
                                                        Box(
                                                            modifier = Modifier
                                                                .size(34.dp)
                                                                .clip(RoundedCornerShape(8.dp))
                                                                .background(
                                                                    when {
                                                                        isSelectedDay -> MaterialTheme.colorScheme.primary
                                                                        d == currentDay -> MaterialTheme.colorScheme.primaryContainer
                                                                        else -> MaterialTheme.colorScheme.surfaceContainerHigh
                                                                    }
                                                                )
                                                                .clickable {
                                                                    val newCal = java.util.Calendar.getInstance().apply {
                                                                        timeInMillis = targetTimestamp
                                                                        set(java.util.Calendar.DAY_OF_MONTH, d)
                                                                    }
                                                                    targetTimestamp = newCal.timeInMillis
                                                                },
                                                            contentAlignment = Alignment.Center
                                                        ) {
                                                            Text(
                                                                text = d.toString(),
                                                                fontSize = 11.sp,
                                                                fontWeight = FontWeight.Bold,
                                                                color = if (isSelectedDay) Color.White else MaterialTheme.colorScheme.onSurface
                                                            )
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }

                                // Quick control actions
                                item {
                                    Column(
                                        verticalArrangement = Arrangement.spacedBy(10.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        // Save changes Button
                                        Button(
                                            onClick = {
                                                if (titleText.isNotBlank()) {
                                                    viewModel.updateTask(selectedTask.copy(
                                                        title = titleText,
                                                        subject = subjectText,
                                                        priority = priorityText,
                                                        timestamp = targetTimestamp
                                                    ))
                                                    viewModel.triggerToast("Modifications enregistrées !")
                                                    navigateTo("#/all")
                                                } else {
                                                    viewModel.triggerToast("Le titre ne peut pas être vide !")
                                                }
                                            },
                                            modifier = Modifier.fillMaxWidth().height(48.dp),
                                            shape = RoundedCornerShape(12.dp)
                                        ) {
                                            Icon(Icons.Default.Check, contentDescription = null)
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text("Enregistrer", fontWeight = FontWeight.Bold)
                                        }

                                        // Finish Toggle Button
                                        Button(
                                            onClick = {
                                                viewModel.toggleTaskCompletion(selectedTask)
                                                navigateTo("#/all")
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                                            modifier = Modifier.fillMaxWidth().height(48.dp),
                                            shape = RoundedCornerShape(12.dp)
                                        ) {
                                            Icon(
                                                imageVector = if (selectedTask.isCompleted) Icons.Default.Refresh else Icons.Default.CheckCircle,
                                                contentDescription = null
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(
                                                if (selectedTask.isCompleted) "Remettre en tâche à faire" else "Marquer comme terminée",
                                                fontWeight = FontWeight.Bold
                                            )
                                        }

                                        // Delete Button
                                        OutlinedButton(
                                            onClick = {
                                                viewModel.deleteTask(selectedTask)
                                                navigateTo("#/all")
                                            },
                                            colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.4f)),
                                            modifier = Modifier.fillMaxWidth().height(48.dp),
                                            shape = RoundedCornerShape(12.dp)
                                        ) {
                                            Icon(Icons.Default.Delete, contentDescription = null)
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text("Supprimer la tâche d'étude", fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // --- ROUTE: #/stats ---
                    routeState == "#/stats" -> {
                        val total = tasks.size
                        val finished = tasks.count { it.isCompleted }
                        val pending = total - finished
                        val rate = if (total > 0) (finished * 100) / total else 0

                        val highPriority = tasks.count { it.priority == "Élevé" }
                        val normalPriority = tasks.count { it.priority == "Moyen" }
                        val lowPriority = tasks.count { it.priority == "Faible" }

                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(16.dp),
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(bottom = 72.dp)
                        ) {
                            item {
                                Text(
                                    "Analyses de productivité d'études",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }

                            // Radial progress indicator for completions
                            item {
                                Card(
                                    shape = RoundedCornerShape(20.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(20.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier.size(90.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            CircularProgressIndicator(
                                                progress = rate.toFloat() / 100f,
                                                strokeWidth = 8.dp,
                                                color = MaterialTheme.colorScheme.primary,
                                                trackColor = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f),
                                                modifier = Modifier.fillMaxSize()
                                            )
                                            Text(
                                                text = "$rate%",
                                                style = MaterialTheme.typography.titleLarge,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                        }
                                        Column {
                                            Text("Taux de Réussite", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                            Text("$finished tâches complétées sur $total au total d'étude", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text("Objectif quotidien : Continuer à progresser chaque jour !", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.secondary, fontWeight = FontWeight.SemiBold)
                                        }
                                    }
                                }
                            }

                            // Total statistics metrics widgets row
                            item {
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Card(
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(16.dp),
                                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh)
                                    ) {
                                        Column(modifier = Modifier.padding(14.dp)) {
                                            Text("$pending", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error)
                                            Text("À faire", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                    }

                                    Card(
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(16.dp),
                                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh)
                                    ) {
                                        Column(modifier = Modifier.padding(14.dp)) {
                                            Text("$finished", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = Color(0xFF2E7D32))
                                            Text("Complétées", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                    }
                                }
                            }

                            // Priorities Breakdown
                            item {
                                Card(
                                    shape = RoundedCornerShape(20.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                        Text("Répartition par Priorités", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                        
                                        // Priority High
                                        Column {
                                            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                                Text("Élevée (DM & DS)", style = MaterialTheme.typography.bodySmall)
                                                Text("$highPriority tâches", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                                            }
                                            LinearProgressIndicator(
                                                progress = if (total > 0) highPriority.toFloat() / total.toFloat() else 0f,
                                                color = Color(0xFFD32F2F),
                                                trackColor = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f),
                                                modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape)
                                            )
                                        }

                                        // Priority Medium
                                        Column {
                                            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                                Text("Moyenne", style = MaterialTheme.typography.bodySmall)
                                                Text("$normalPriority tâches", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                                            }
                                            LinearProgressIndicator(
                                                progress = if (total > 0) normalPriority.toFloat() / total.toFloat() else 0f,
                                                color = Color(0xFFF57C00),
                                                trackColor = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f),
                                                modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape)
                                            )
                                        }

                                        // Priority Low
                                        Column {
                                            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                                Text("Faible (Optionnelle)", style = MaterialTheme.typography.bodySmall)
                                                Text("$lowPriority tâches", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                                            }
                                            LinearProgressIndicator(
                                                progress = if (total > 0) lowPriority.toFloat() / total.toFloat() else 0f,
                                                color = Color(0xFF1976D2),
                                                trackColor = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f),
                                                modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape)
                                            )
                                        }
                                    }
                                }
                            }

                            // Subject representation breakdown
                            item {
                                Card(
                                    shape = RoundedCornerShape(20.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                        Text("Répartition par Matière", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                        
                                        listOf("Mathématiques", "Sciences Physiques", "Histoire & Géographie", "Économie", "Littérature").forEach { subject ->
                                            val qty = tasks.count { it.subject == subject }
                                            val doneQty = tasks.count { it.subject == subject && it.isCompleted }
                                            Row(
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically,
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                                    Box(modifier = Modifier.size(10.dp).background(MaterialTheme.colorScheme.primary, CircleShape))
                                                    Text(subject, style = MaterialTheme.typography.bodyMedium)
                                                }
                                                Text("$doneQty/$qty faites", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TaskItemCard(
    task: Task,
    onToggleCompletion: () -> Unit,
    onDelete: () -> Unit
) {
    val animatedAlpha by animateFloatAsState(
        targetValue = if (task.isCompleted) 0.55f else 1.0f,
        animationSpec = tween(durationMillis = 300),
        label = "taskAlpha"
    )

    val animatedBorderColor by animateColorAsState(
        targetValue = if (task.isCompleted) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.outline,
        animationSpec = tween(durationMillis = 300),
        label = "borderColor"
    )

    val animatedBgColor by animateColorAsState(
        targetValue = if (task.isCompleted) MaterialTheme.colorScheme.secondary.copy(alpha = 0.12f) else Color.Transparent,
        animationSpec = tween(durationMillis = 300),
        label = "bgColor"
    )

    val animatedCardBg by animateColorAsState(
        targetValue = if (task.isCompleted) MaterialTheme.colorScheme.surfaceContainerLow.copy(alpha = 0.6f) else MaterialTheme.colorScheme.surfaceContainerLowest,
        animationSpec = tween(durationMillis = 300),
        label = "cardBg"
    )

    val animatedCardBorderColor by animateColorAsState(
        targetValue = if (task.isCompleted) Color.Transparent else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f),
        animationSpec = tween(durationMillis = 300),
        label = "cardBorderColor"
    )

    val checkmarkScale by animateFloatAsState(
        targetValue = if (task.isCompleted) 1.0f else 0.0f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "checkmarkScale"
    )

    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = animatedCardBg
        ),
        modifier = Modifier
            .fillMaxWidth()
            .border(
                1.dp,
                animatedCardBorderColor,
                RoundedCornerShape(24.dp)
            ),
        elevation = CardDefaults.cardElevation(if (task.isCompleted) 0.dp else 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .alpha(animatedAlpha)
                .padding(20.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.weight(1f)
            ) {
                // Interactive Custom Checkbox Circle Drawing
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(animatedBgColor)
                        .border(
                            width = 2.dp,
                            color = animatedBorderColor,
                            shape = CircleShape
                        )
                        .clickable { onToggleCompletion() },
                    contentAlignment = Alignment.Center
                ) {
                    if (checkmarkScale > 0.01f) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = "Complete",
                            tint = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier
                                .size(18.dp)
                                .scale(checkmarkScale)
                        )
                    }
                }

                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        // Tag for priority
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(
                                    when (task.priority) {
                                        "Élevé" -> MaterialTheme.colorScheme.errorContainer
                                        "Moyen" -> MaterialTheme.colorScheme.secondaryContainer
                                        else -> PrimaryFixed
                                    }
                                )
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = task.priority.uppercase(),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = when (task.priority) {
                                    "Élevé" -> MaterialTheme.colorScheme.onErrorContainer
                                    "Moyen" -> MaterialTheme.colorScheme.onSecondaryContainer
                                    else -> OnPrimaryFixedVariant
                                }
                            )
                        }

                        Text(
                            text = task.subject,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = task.title,
                        style = MaterialTheme.typography.titleMedium.copy(
                            textDecoration = if (task.isCompleted) TextDecoration.LineThrough else TextDecoration.None
                        ),
                        color = MaterialTheme.colorScheme.onSurface,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            IconButton(onClick = onDelete) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "Supprimer la tâche",
                    tint = MaterialTheme.colorScheme.error.copy(alpha = 0.5f)
                )
            }
        }
    }
}


// TAB 3: Progress & Stats (Mes Progrès)
@Composable
fun ProgressScreen(
    viewModel: StudyViewModel,
    onVoirBadgesClick: () -> Unit
) {
    val totalHours by viewModel.totalStudyHours.collectAsState()
    val completedCourses by viewModel.completedCourses.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        item {
            Column(modifier = Modifier.padding(top = 16.dp)) {
                Text(
                    text = "Mes Progrès",
                    style = MaterialTheme.typography.headlineLarge,
                    color = MaterialTheme.colorScheme.onSurface,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Continue comme ça, tu es sur la bonne voie !",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Main Progress Card representation
        item {
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        1.dp,
                        MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f),
                        RoundedCornerShape(24.dp)
                    ),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(120.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.secondary.copy(alpha = 0.05f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = "Growth Trophy Medal",
                            tint = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.size(64.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Card(
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)
                        ) {
                            Column(
                                modifier = Modifier
                                    .padding(16.dp)
                                    .fillMaxWidth(),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Schedule,
                                    tint = MaterialTheme.colorScheme.primary,
                                    contentDescription = "Timer hours"
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "$totalHours hrs",
                                    style = MaterialTheme.typography.displayLarge.copy(
                                        fontSize = 24.sp,
                                        fontWeight = FontWeight.Bold
                                    ),
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    text = "Heures Totales",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Card(
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)
                        ) {
                            Column(
                                modifier = Modifier
                                    .padding(16.dp)
                                    .fillMaxWidth(),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Book,
                                    tint = MaterialTheme.colorScheme.secondary,
                                    contentDescription = "Studies total"
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "$completedCourses",
                                    style = MaterialTheme.typography.displayLarge.copy(
                                        fontSize = 24.sp,
                                        fontWeight = FontWeight.Bold
                                    ),
                                    color = MaterialTheme.colorScheme.secondary
                                )
                                Text(
                                    text = "Cours Finis",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }

        // Weekly Stats and Pomodoro Dashboard representation
        item {
            var activeDashboardTab by remember { mutableStateOf("tasks") } // "tasks" or "pomodoro"
            var selectedDayIndex by remember { mutableStateOf(3) } // Thursday default
            
            val daysList = listOf("Lun", "Mar", "Mer", "Jeu", "Ven", "Sam", "Dim")
            
            // Tasks completed data (e.g., number out of max 8)
            val tasksData = listOf(3, 5, 2, 7, 4, 1, 0)
            // Pomodoro successful sessions data (e.g., number out of max 6)
            val pomodoroData = listOf(2, 4, 1, 5, 3, 2, 0)
            
            val primaryColor = MaterialTheme.colorScheme.primary
            val secondaryColor = MaterialTheme.colorScheme.secondary
            val tertiaryColor = MaterialTheme.colorScheme.tertiary
            
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        1.dp,
                        MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f),
                        RoundedCornerShape(24.dp)
                    ),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    // Title and segmented animated pills
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Tableau de Bord Études",
                            style = MaterialTheme.typography.titleLarge,
                            color = MaterialTheme.colorScheme.onSurface,
                            fontWeight = FontWeight.Bold
                        )
                        
                        // Small Refresh Icon
                        IconButton(onClick = { 
                            viewModel.triggerToast("Données rafraîchies à l'instant !")
                        }) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Refresh stats",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                    
                    Spacer(modifier = Modifier.height(12.dp))
                    
                    // Sliding segment Tab Selector
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(99.dp))
                            .background(MaterialTheme.colorScheme.surfaceContainerLow)
                            .padding(4.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        listOf(
                            Pair("tasks", "Tâches Complétées"),
                            Pair("pomodoro", "Sessions Pomodoro")
                        ).forEach { tab ->
                            val isSelected = activeDashboardTab == tab.first
                            val animatedTabBg by animateColorAsState(
                                targetValue = if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent,
                                animationSpec = tween(250),
                                label = "tabBg"
                            )
                            val animatedTabTxt by animateColorAsState(
                                targetValue = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                animationSpec = tween(250),
                                label = "tabTxt"
                            )
                            
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(99.dp))
                                    .background(animatedTabBg)
                                    .clickable { activeDashboardTab = tab.first }
                                    .padding(vertical = 10.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = tab.second,
                                    color = animatedTabTxt,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                    
                    Spacer(modifier = Modifier.height(24.dp))
                    
                    // Selected value pop-up badge
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier
                                .clip(RoundedCornerShape(99.dp))
                                .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f))
                                .padding(horizontal = 16.dp, vertical = 6.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .background(
                                        if (activeDashboardTab == "tasks") primaryColor else secondaryColor,
                                        CircleShape
                                    )
                            )
                            val activeVal = if (activeDashboardTab == "tasks") tasksData[selectedDayIndex] else pomodoroData[selectedDayIndex]
                            val labelText = if (activeDashboardTab == "tasks") {
                                "Tâches complétées le ${daysList[selectedDayIndex]} : $activeVal/8"
                            } else {
                                "Focus Pomodoro réussis le ${daysList[selectedDayIndex]} : $activeVal/6"
                            }
                            Text(
                                text = labelText,
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                ),
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                    }
                    
                    Spacer(modifier = Modifier.height(14.dp))
                    
                    // Drawing container
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(150.dp)
                    ) {
                        if (activeDashboardTab == "tasks") {
                            // GRAPHIC A: ANIMATED ROUNDED CHATTER COLUMN CHART
                            Row(
                                modifier = Modifier.fillMaxSize(),
                                verticalAlignment = Alignment.Bottom,
                                horizontalArrangement = Arrangement.SpaceEvenly
                            ) {
                                tasksData.forEachIndexed { index, value ->
                                    val isHighlighted = selectedDayIndex == index
                                    val maxVal = 8f
                                    val heightPercentage = value.toFloat() / maxVal
                                    
                                    val animatedStretchFraction by animateFloatAsState(
                                        targetValue = heightPercentage,
                                        animationSpec = spring(
                                            dampingRatio = Spring.DampingRatioMediumBouncy,
                                            stiffness = Spring.StiffnessLow
                                        ),
                                        label = "stretchBar"
                                    )
                                    
                                    val barColor by animateColorAsState(
                                        targetValue = if (isHighlighted) primaryColor else primaryColor.copy(alpha = 0.25f),
                                        animationSpec = tween(200),
                                        label = "barColor"
                                    )
                                    
                                    val barWidth by animateDpAsState(
                                        targetValue = if (isHighlighted) 28.dp else 22.dp,
                                        animationSpec = spring(stiffness = Spring.StiffnessMedium),
                                        label = "barWidth"
                                    )
                                    
                                    Column(
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.Bottom,
                                        modifier = Modifier
                                            .weight(1f)
                                            .fillMaxHeight()
                                            .clickable { selectedDayIndex = index }
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .width(barWidth)
                                                .fillMaxHeight(animatedStretchFraction)
                                                .clip(RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp))
                                                .background(barColor)
                                                .border(
                                                    width = if (isHighlighted) 1.5.dp else 0.dp,
                                                    color = MaterialTheme.colorScheme.onPrimary,
                                                    shape = RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp)
                                                ),
                                            contentAlignment = Alignment.TopCenter
                                        ) {
                                            if (isHighlighted && value > 0) {
                                                Box(
                                                    modifier = Modifier
                                                        .padding(top = 4.dp)
                                                        .size(6.dp)
                                                        .background(Color.White, CircleShape)
                                                )
                                            }
                                        }
                                        
                                        Spacer(modifier = Modifier.height(8.dp))
                                        
                                        Text(
                                            text = daysList[index],
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                fontWeight = if (isHighlighted) FontWeight.Bold else FontWeight.Normal
                                            ),
                                            color = if (isHighlighted) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.outline
                                        )
                                    }
                                }
                            }
                        } else {
                            // GRAPHIC B: ANIMATED NATIVE CANVAS SPLINE GRAPH WITH GRADIENT SHADOW
                            // Uses canvas to paint the bezier path, and overlays touch buttons
                            val animProgress = remember { Animatable(0f) }
                            LaunchedEffect(key1 = activeDashboardTab) {
                                animProgress.animateTo(
                                    targetValue = 1f,
                                    animationSpec = tween(800, easing = LinearOutSlowInEasing)
                                )
                            }
                            
                            val secondaryFixedColor = secondaryColor
                            val secondaryFixedDimColor = secondaryColor.copy(alpha = 0.2f)
                            
                            Canvas(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(horizontal = 14.dp, vertical = 12.dp)
                            ) {
                                val width = size.width
                                val height = size.height
                                val maxVal = 6f
                                
                                val points = pomodoroData.mapIndexed { idx, value ->
                                    val x = (width / (pomodoroData.size - 1)) * idx
                                    val valFrac = (value.toFloat() / maxVal) * animProgress.value
                                    val y = height - (height * valFrac)
                                    androidx.compose.ui.geometry.Offset(x, y)
                                }
                                
                                // Draw horizontal target grids
                                for (i in 1..3) {
                                    val gridY = height - (height * (i.toFloat() / 4f))
                                    drawLine(
                                        color = Color.LightGray.copy(alpha = 0.25f),
                                        start = androidx.compose.ui.geometry.Offset(0f, gridY),
                                        end = androidx.compose.ui.geometry.Offset(width, gridY),
                                        strokeWidth = 1.dp.toPx(),
                                        pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(
                                            floatArrayOf(10f, 10f), 0f
                                        )
                                    )
                                }
                                
                                // Build curve Path
                                val path = Path().apply {
                                    if (points.isNotEmpty()) {
                                        moveTo(points[0].x, points[0].y)
                                        for (i in 1 until points.size) {
                                            val pPrev = points[i - 1]
                                            val pCurr = points[i]
                                            val controlX = (pPrev.x + pCurr.x) / 2
                                            cubicTo(
                                                controlX, pPrev.y,
                                                controlX, pCurr.y,
                                                pCurr.x, pCurr.y
                                            )
                                        }
                                    }
                                }
                                
                                // Draw Area under the Curve Gradient
                                val fillPath = Path().apply {
                                    addPath(path)
                                    lineTo(width, height)
                                    lineTo(0f, height)
                                    close()
                                }
                                drawPath(
                                    path = fillPath,
                                    brush = Brush.verticalGradient(
                                        colors = listOf(
                                            secondaryFixedColor.copy(alpha = 0.35f),
                                            secondaryFixedColor.copy(alpha = 0.0f)
                                        )
                                    )
                                )
                                
                                // Draw Stroke Border
                                drawPath(
                                    path = path,
                                    color = secondaryFixedColor,
                                    style = Stroke(
                                        width = 3.dp.toPx(),
                                        cap = StrokeCap.Round
                                    )
                                )
                                
                                // Draw interactive vertex points & pulsing halos
                                points.forEachIndexed { idx, point ->
                                    val isPointHighlighted = selectedDayIndex == idx
                                    drawCircle(
                                        color = if (isPointHighlighted) secondaryFixedColor else secondaryFixedColor.copy(alpha = 0.5f),
                                        radius = if (isPointHighlighted) 7.dp.toPx() else 4.dp.toPx(),
                                        center = point
                                    )
                                    if (isPointHighlighted) {
                                        drawCircle(
                                            color = secondaryFixedColor.copy(alpha = 0.15f),
                                            radius = 16.dp.toPx(),
                                            center = point
                                        )
                                    }
                                }
                            }
                            
                            // Touch layer overlay over the canvas (invisible interactive areas for flawless target hitboxes!)
                            Row(
                                modifier = Modifier.fillMaxSize(),
                                horizontalArrangement = Arrangement.SpaceEvenly
                            ) {
                                pomodoroData.forEachIndexed { index, _ ->
                                    val isHighlighted = selectedDayIndex == index
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .fillMaxHeight()
                                            .clickable { selectedDayIndex = index },
                                        contentAlignment = Alignment.BottomCenter
                                    ) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Text(
                                                text = daysList[index],
                                                style = MaterialTheme.typography.labelSmall.copy(
                                                    fontWeight = if (isHighlighted) FontWeight.Bold else FontWeight.Normal
                                                ),
                                                color = if (isHighlighted) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.outline,
                                                modifier = Modifier.padding(bottom = 0.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                    
                    Spacer(modifier = Modifier.height(18.dp))
                    
                    // Summary details row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(99.dp))
                                .background(PrimaryFixed)
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text("Maths: 12h", style = MaterialTheme.typography.labelSmall, color = OnPrimaryFixed)
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(99.dp))
                                .background(SecondaryFixed)
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text("Physique: 8h", style = MaterialTheme.typography.labelSmall, color = OnSecondaryFixedVariant)
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(99.dp))
                                .background(TertiaryFixed)
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text("Philo: 4h", style = MaterialTheme.typography.labelSmall, color = OnTertiaryFixed)
                        }
                    }
                }
            }
        }

        // Achievements Section (Badges)
        item {
            Column(modifier = Modifier.padding(bottom = 24.dp)) {
                Text(
                    text = "Badges de Réussite",
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onSurface,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Badge 1 Unlocked
                    BadgeItem(
                        icon = Icons.Default.Star,
                        tint = MaterialTheme.colorScheme.secondary,
                        bgColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.3f),
                        title = "Lève-tôt",
                        isUnlocked = true
                    )
                    // Badge 2 Unlocked
                    BadgeItem(
                        icon = Icons.Default.Favorite,
                        tint = MaterialTheme.colorScheme.primary,
                        bgColor = PrimaryFixed.copy(alpha = 0.3f),
                        title = "Série 7 jours",
                        isUnlocked = true
                    )
                    // Badge 3 Locked
                    BadgeItem(
                        icon = Icons.Default.Lock,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
                        bgColor = MaterialTheme.colorScheme.surfaceContainerHighest.copy(alpha = 0.6f),
                        title = "Maître Math",
                        isUnlocked = false
                    )
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Collapsible Badges Explainer Accordion (Slow, upward animation)
                var isExplainerExpanded by remember { mutableStateOf(false) }
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.15f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { isExplainerExpanded = !isExplainerExpanded }
                        .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.1f), RoundedCornerShape(16.dp))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Info,
                                    tint = MaterialTheme.colorScheme.primary,
                                    contentDescription = "Badges Guide"
                                )
                                Text(
                                    text = "Comment débloquer les Badges ?",
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            Icon(
                                imageVector = if (isExplainerExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                                contentDescription = if (isExplainerExpanded) "Collapse" else "Expand",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }

                        AnimatedVisibility(
                            visible = isExplainerExpanded,
                            enter = expandVertically(animationSpec = tween(600)) + fadeIn(animationSpec = tween(600)),
                            exit = shrinkVertically(animationSpec = tween(600)) + fadeOut(animationSpec = tween(600))
                        ) {
                            Column(
                                modifier = Modifier.padding(top = 10.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    text = "Chaque badge couronne vos efforts de révision :",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(bottom = 4.dp)
                                )
                                
                                listOf(
                                    Triple("☀️ Lève-tôt", "Commencer et compléter une session d'au moins 25 minutes de Pomodoro avant 8h00 du matin.", true),
                                    Triple("🔥 Série 7 jours", "Compléter au moins une tâche d'étude planifiée par jour pendant une semaine.", true),
                                    Triple("📐 Maître Math", "Obtenir un score parfait (100% de bonnes réponses) à un quiz de Mathématiques.", false),
                                    Triple("🧠 Concentration Pro", "Cumuler 10 sessions complètes du minuteur Pomodoro.", false)
                                ).forEach { (title, desc, unlocked) ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(if (unlocked) MaterialTheme.colorScheme.primary.copy(alpha = 0.05f) else Color.Transparent)
                                            .padding(6.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(24.dp)
                                                .background(if (unlocked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceContainerHighest, CircleShape),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = if (unlocked) Icons.Default.Check else Icons.Default.Lock,
                                                tint = if (unlocked) Color.White else MaterialTheme.colorScheme.outline,
                                                modifier = Modifier.size(14.dp),
                                                contentDescription = null
                                            )
                                        }
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(title, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                                            Text(desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                Button(
                    onClick = onVoirBadgesClick,
                    shape = RoundedCornerShape(99.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(99.dp)),
                    contentPadding = PaddingValues(vertical = 12.dp)
                ) {
                    Text(
                        "Voir tous les badges",
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun BadgeItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    tint: Color,
    bgColor: Color,
    title: String,
    isUnlocked: Boolean
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp),
        modifier = Modifier.width(96.dp)
    ) {
        Box(
            modifier = Modifier
                .size(72.dp)
                .clip(CircleShape)
                .background(bgColor)
                .border(
                    width = 1.5.dp,
                    color = if (isUnlocked) tint.copy(alpha = 0.2f) else MaterialTheme.colorScheme.outlineVariant,
                    shape = CircleShape
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                tint = tint,
                contentDescription = title,
                modifier = Modifier.size(36.dp)
            )
        }
        Text(
            text = title,
            style = MaterialTheme.typography.labelSmall,
            color = if (isUnlocked) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
            textAlign = TextAlign.Center,
            fontWeight = if (isUnlocked) FontWeight.Bold else FontWeight.Normal
        )
    }
}


// TAB 4: Profile / Settings Settings Panel with Switches
@Composable
fun ProfileScreen(
    viewModel: StudyViewModel,
    onTabSelected: (String) -> Unit,
    onLeaderboardClick: () -> Unit
) {
    var notificationPreferencesSaved by remember { mutableStateOf(false) }

    val focusAlertsState by viewModel.focusAlerts.collectAsState()
    val breakRemindersState by viewModel.breakReminders.collectAsState()
    val goalRemindersState by viewModel.goalReminders.collectAsState()
    val weeklyReportsState by viewModel.weeklyReports.collectAsState()
    val studyGroupInvitesState by viewModel.studyGroupInvites.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        item {
            Column(
                modifier = Modifier
                    .padding(top = 16.dp)
                    .fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // User big photo avatar placeholder
                Box(
                    modifier = Modifier
                        .size(110.dp)
                        .clip(CircleShape)
                        .background(PrimaryFixed)
                        .border(3.dp, MaterialTheme.colorScheme.primaryContainer, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Person,
                        contentDescription = "Big profile photo",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(64.dp)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "Alex Chen",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "alex.chen@university.edu",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Leaderboard Entry CTA
        item {
            Card(
                onClick = onLeaderboardClick,
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = PrimaryFixed),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Star,
                            tint = OnPrimaryFixedVariant,
                            contentDescription = "Leaderboard stats"
                        )
                        Text(
                            "Afficher le Classement Global",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = OnPrimaryFixedVariant
                        )
                    }
                    Icon(
                        imageVector = Icons.Default.ArrowForward,
                        contentDescription = "Forward to leaderboard",
                        tint = OnPrimaryFixedVariant
                    )
                }
            }
        }

        // STUDY FOCUS Switches
        item {
            SettingsSettingsSection(
                title = "CONCENTRATION D'ÉTUDE",
                icon = Icons.Default.Schedule,
                tintColor = MaterialTheme.colorScheme.primary
            ) {
                SettingsSwitchRow(
                    label = "Alertes de concentration",
                    subtitle = "Rappels pour démarrer vos sessions de concentration.",
                    checked = focusAlertsState,
                    onCheckedChange = { viewModel.focusAlerts.value = it }
                )
                SettingsSwitchRow(
                    label = "Rappels de pause",
                    subtitle = "Petits rappels pour vous reposer et reposer vos yeux.",
                    checked = breakRemindersState,
                    onCheckedChange = { viewModel.breakReminders.value = it }
                )
            }
        }

        // GOALS & PROGRESS Switches
        item {
            SettingsSettingsSection(
                title = "OBJECTIFS & PROGRÈS",
                icon = Icons.Default.Flag,
                tintColor = MaterialTheme.colorScheme.secondary
            ) {
                SettingsSwitchRow(
                    label = "Rappels d'objectifs",
                    subtitle = "Suivi quotidien de vos objectifs d'apprentissage.",
                    checked = goalRemindersState,
                    onCheckedChange = { viewModel.goalReminders.value = it }
                )
                SettingsSwitchRow(
                    label = "Rapports hebdomadaires",
                    subtitle = "Résumé de vos réussites tous les dimanches.",
                    checked = weeklyReportsState,
                    onCheckedChange = { viewModel.weeklyReports.value = it }
                )
            }
        }

        // Save Preferences Button
        item {
            Button(
                onClick = {
                    notificationPreferencesSaved = true
                    viewModel.triggerToast("Préférences enregistrées avec succès !")
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                shape = RoundedCornerShape(99.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                contentPadding = PaddingValues(vertical = 14.dp)
            ) {
                Text(
                    text = "Enregistrer les préférences",
                    style = MaterialTheme.typography.titleMedium.copy(fontSize = 16.sp),
                    color = MaterialTheme.colorScheme.onPrimary
                )
            }
        }
    }
}

@Composable
fun SettingsSettingsSection(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    tintColor: Color,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
        modifier = Modifier
            .fillMaxWidth()
            .border(
                1.dp,
                MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f),
                RoundedCornerShape(16.dp)
            ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.padding(bottom = 12.dp)
            ) {
                Icon(
                    imageVector = icon,
                    tint = tintColor,
                    contentDescription = title,
                    modifier = Modifier.size(20.dp)
                )
                Text(
                    title,
                    style = MaterialTheme.typography.labelLarge,
                    color = tintColor,
                    fontWeight = FontWeight.Bold
                )
            }
            content()
        }
    }
}

@Composable
fun SettingsSwitchRow(
    label: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                label,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                subtitle,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(checkedTrackColor = MaterialTheme.colorScheme.primary)
        )
    }
}


// POP-UP / SUB-TAB 5: Leaderboard Listing Screen ("Weekly Champs")
@Composable
fun LeaderboardScreen(
    onBack: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        item {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 16.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Retour")
                    }
                    Text(
                        text = "Meilleurs de la Semaine",
                        style = MaterialTheme.typography.headlineLarge,
                        color = MaterialTheme.colorScheme.onSurface,
                        fontWeight = FontWeight.Bold
                    )
                }
                
                // Little dropdown indicating monthly/weekly (Image 4)
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier
                        .clip(RoundedCornerShape(99.dp))
                        .background(MaterialTheme.colorScheme.surfaceContainerHigh)
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text("Hebdo", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    Icon(Icons.Default.ArrowDropDown, contentDescription = "Select range", modifier = Modifier.size(16.dp))
                }
            }
        }

        // Celebrating top 15% header card
        item {
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5E9)), // Clean light green background (Image 4)
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Color(0xFFC8E6C9), RoundedCornerShape(24.dp))
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF52C77A)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.EmojiEvents,
                            contentDescription = "Cup",
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Column {
                        Text(
                            text = "Vous êtes dans le top 15% !",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF2E7D32)
                        )
                        Text(
                            text = "Excellent travail ! Continuez ainsi pour monter sur le podium.",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF1B5E20).copy(alpha = 0.8f)
                        )
                    }
                }
            }
        }

        // Podium top 3 graphic
        item {
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        1.dp,
                        MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f),
                        RoundedCornerShape(24.dp)
                    ),
                elevation = CardDefaults.cardElevation(2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        "Podium de la Semaine",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Spacer(modifier = Modifier.height(24.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        // 2nd (Sarah K)
                        PodiumColumn(
                            name = "Sarah K.",
                            hours = "38h",
                            place = "2",
                            heightPct = 0.65f,
                            color = Color(0xFFB0BEC5), // Silver gray
                            badgeColor = Color(0xFF78909C)
                        )
                        // 1st (James L)
                        PodiumColumn(
                            name = "James L.",
                            hours = "42h",
                            place = "1",
                            heightPct = 1.0f,
                            color = Color(0xFF52C77A), // Success Emerald Green
                            badgeColor = Color(0xFF2E7D32),
                            isWinner = true
                        )
                        // 3rd (Maya R)
                        PodiumColumn(
                            name = "Maya R.",
                            hours = "32h",
                            place = "3",
                            heightPct = 0.45f,
                            color = Color(0xFFCFD8DC), // Bronze/Slate
                            badgeColor = Color(0xFF90A4AE)
                        )
                    }
                }
            }
        }

        // Global rankings list
        item {
            Text(
                "Classement Général",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 8.dp)
            )
        }

        items(
            listOf(
                RankItem(4, "Alex Chen", "28.5 hrs", 0.7f, false),
                RankItem(5, "You (Felix)", "26.2 hrs", 0.65f, true),
                RankItem(6, "Sasha Grey", "24.1 hrs", 0.6f, false),
                RankItem(7, "Tom Wilson", "22.8 hrs", 0.55f, false)
            )
        ) { rank ->
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (rank.isUser) Color(0xFF005EDA) else MaterialTheme.colorScheme.surfaceContainerLowest
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        1.dp,
                        if (rank.isUser) Color.Transparent else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f),
                        RoundedCornerShape(16.dp)
                    ),
                elevation = CardDefaults.cardElevation(if (rank.isUser) 4.dp else 1.dp)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = rank.pos.toString(),
                        style = MaterialTheme.typography.titleMedium,
                        color = if (rank.isUser) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.width(20.dp)
                    )
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .background(
                                if (rank.isUser) Color.White.copy(alpha = 0.2f) else PrimaryFixed,
                                CircleShape
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            tint = if (rank.isUser) Color.White else MaterialTheme.colorScheme.primary,
                            contentDescription = "Avatar"
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                rank.name,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = if (rank.isUser) Color.White else MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                rank.hours,
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                color = if (rank.isUser) Color.White else MaterialTheme.colorScheme.onSurface
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        LinearProgressIndicator(
                            progress = { rank.percentage },
                            color = if (rank.isUser) Color(0xFF52C77A) else MaterialTheme.colorScheme.primary,
                            trackColor = if (rank.isUser) Color.White.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceContainer,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(CircleShape)
                        )
                    }
                }
            }
        }

        // "View All Friends" clickable centered action (Image 4)
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { }
                    .padding(vertical = 4.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "View All Friends",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF005EDA)
                )
            }
        }

        // Friends Activity Title (Image 4)
        item {
            Text(
                "Friends Activity",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 10.dp)
            )
        }

        // Friends Activity Horizontal scroll cards slider (Image 4)
        item {
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(bottom = 16.dp)
            ) {
                items(3) { index ->
                    val name = listOf("Oliver", "Lucy", "Jordan")[index]
                    val activity = listOf("Studying Biology • 45m", "Aced Exam! • 10m ago", "Focus Session • 2h ago")[index]
                    val avatarColor = listOf(Color(0xFFE8F1FF), Color(0xFFE8F8EF), Color(0xFFFFF2E6))[index]
                    val iconColor = listOf(Color(0xFF005EDA), Color(0xFF52C77A), Color(0xFFFF9800))[index]
                    
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                        modifier = Modifier
                            .width(185.dp)
                            .border(
                                1.dp,
                                MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f),
                                RoundedCornerShape(16.dp)
                            )
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(avatarColor),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = name.take(1),
                                    fontWeight = FontWeight.Bold,
                                    color = iconColor,
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }
                            Column {
                                Text(
                                    name,
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    activity,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PodiumColumn(
    name: String,
    hours: String,
    place: String,
    heightPct: Float,
    color: Color,
    badgeColor: Color,
    isWinner: Boolean = false
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp),
        modifier = Modifier.width(90.dp)
    ) {
        // Icon circular avatar representer
        Box(
            modifier = Modifier
                .size(54.dp)
                .background(Color.White, CircleShape)
                .border(2.dp, color, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Default.Person,
                    contentDescription = name,
                    tint = if (isWinner) Color(0xFF005EDA) else MaterialTheme.colorScheme.outline
                )
                
                // Overlay Winner Star/Badge
                if (isWinner) {
                    Box(
                        modifier = Modifier
                            .offset(x = 18.dp, y = (-18).dp)
                            .size(16.dp)
                            .background(Color(0xFFFFB300), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Star, contentDescription = null, tint = Color.White, modifier = Modifier.size(10.dp))
                    }
                }
            }
        }
        Text(
            name,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )
        Text(
            hours,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.ExtraBold,
            color = if (isWinner) Color(0xFF52C77A) else MaterialTheme.colorScheme.secondary
        )
        // Bar
        Box(
            modifier = Modifier
                .fillMaxWidth(0.85f)
                .height(100.dp * heightPct)
                .clip(RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
                .background(color),
            contentAlignment = Alignment.Center
        ) {
            Text(
                place,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.ExtraBold,
                color = Color.White
            )
        }
    }
}

data class RankItem(
    val pos: Int,
    val name: String,
    val hours: String,
    val percentage: Float,
    val isUser: Boolean
)

@Composable
fun ExploreScreen(
    viewModel: StudyViewModel
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("Tout") }

    val categories = listOf("Tout", "Maths", "Histoire", "Science", "Économie")

    val studyGuides = listOf(
        StudyGuideItem(
            title = "Notes de Physique Quantique Avancée",
            desc = "Résumé complet du programme 2026 incluant la dualité onde-particule et l'équation de Schrödinger.",
            category = "Science",
            author = "Sarah Jenkins",
            downloads = "1.2k téléchargements",
            isBookmarked = true
        ),
        StudyGuideItem(
            title = "Guide d'Économie d'Après-Guerre",
            desc = "Analyse approfondie des flux commerciaux mondiaux de 1945 à 1960 avec graphiques détaillés.",
            category = "Économie",
            author = "Marcus Thorne",
            downloads = "840 téléchargements",
            isBookmarked = false
        ),
        StudyGuideItem(
            title = "Analyse III : Formules d'Intégration",
            desc = "Fiche de révision complète pour les intégrales triples, de surface et le théorème de Stokes.",
            category = "Maths",
            author = "Alex Chen",
            downloads = "2.1k téléchargements",
            isBookmarked = true
        ),
        StudyGuideItem(
            title = "Histoire des Civilisations Anciennes",
            desc = "Introduction chronologique et cartes des empires de Mésopotamie et d'Égypte antique.",
            category = "Histoire",
            author = "Prof. Dubois",
            downloads = "450 téléchargements",
            isBookmarked = false
        )
    )

    // Filter based on search query and category
    val filteredGuides = studyGuides.filter { guide ->
        (selectedCategory == "Tout" || guide.category == selectedCategory) &&
        (guide.title.contains(searchQuery, ignoreCase = true) || guide.desc.contains(searchQuery, ignoreCase = true))
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 32.dp)
    ) {
        item {
            Text(
                text = "Explorer les cours",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(12.dp))
            
            // Search Input Field
            TextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Rechercher des guides de cours, fiches...") },
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f), RoundedCornerShape(16.dp)),
                leadingIcon = {
                    Icon(Icons.Default.Search, contentDescription = null, tint = MaterialTheme.colorScheme.outline)
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Close, contentDescription = "Effacer")
                        }
                    }
                },
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = MaterialTheme.colorScheme.surfaceContainerLowest,
                    unfocusedContainerColor = MaterialTheme.colorScheme.surfaceContainerLow,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent
                ),
                shape = RoundedCornerShape(16.dp),
                singleLine = true
            )
        }

        // Horizontal tag chips filter row
        item {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(categories) { cat ->
                    val isSelected = selectedCategory == cat
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(99.dp))
                            .background(if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceContainer)
                            .clickable { selectedCategory = cat }
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                    ) {
                        Text(
                            text = cat,
                            color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            }
        }

        item {
            Text(
                text = "Recommandé pour vous",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.padding(top = 8.dp)
            )
        }

        if (filteredGuides.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Aucun guide de cours trouvé pour : \"$searchQuery\"",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.outline,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            items(filteredGuides) { item ->
                StudyGuideCard(
                    item = item,
                    onDownloadClick = {
                        viewModel.triggerToast("Téléchargement lancé pour : ${item.title}")
                    }
                )
            }
        }
    }
}

data class StudyGuideItem(
    val title: String,
    val desc: String,
    val category: String,
    val author: String,
    val downloads: String,
    val isBookmarked: Boolean
)

@Composable
fun StudyGuideCard(
    item: StudyGuideItem,
    onDownloadClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
        modifier = Modifier
            .fillMaxWidth()
            .border(
                1.dp,
                MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f),
                RoundedCornerShape(16.dp)
            ),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Category Chip Tag
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(MaterialTheme.colorScheme.primaryContainer)
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = item.category,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
                
                // Bookmark Icon
                Icon(
                    imageVector = if (item.isBookmarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
            }

            Text(
                text = item.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )

            Text(
                text = item.desc,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 20.sp
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .background(MaterialTheme.colorScheme.surfaceVariant, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                    Text(
                        text = item.author,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.outline
                    )
                }
                
                Button(
                    onClick = onDownloadClick,
                    shape = RoundedCornerShape(99.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier.height(30.dp)
                ) {
                    Text("Accéder", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}


// --- CALENDAR SUPPORT CLASSES & COMPOSABLES ---

data class CalendarDay(
    val dayOfMonth: Int,
    val isCurrentMonth: Boolean,
    val timestamp: Long,
    val isToday: Boolean = false
)

fun isSameDay(time1: Long, time2: Long): Boolean {
    val cal1 = java.util.Calendar.getInstance().apply { timeInMillis = time1 }
    val cal2 = java.util.Calendar.getInstance().apply { timeInMillis = time2 }
    return cal1.get(java.util.Calendar.YEAR) == cal2.get(java.util.Calendar.YEAR) &&
           cal1.get(java.util.Calendar.DAY_OF_YEAR) == cal2.get(java.util.Calendar.DAY_OF_YEAR)
}

fun getDaysInMonth(year: Int, month: Int): List<CalendarDay> {
    val days = mutableListOf<CalendarDay>()
    
    val cal = java.util.Calendar.getInstance().apply {
        clear()
        set(java.util.Calendar.YEAR, year)
        set(java.util.Calendar.MONTH, month - 1)
        set(java.util.Calendar.DAY_OF_MONTH, 1)
    }
    
    val firstDayOfWeek = cal.get(java.util.Calendar.DAY_OF_WEEK)
    val prefixDaysCount = when (firstDayOfWeek) {
        java.util.Calendar.MONDAY -> 0
        java.util.Calendar.TUESDAY -> 1
        java.util.Calendar.WEDNESDAY -> 2
        java.util.Calendar.THURSDAY -> 3
        java.util.Calendar.FRIDAY -> 4
        java.util.Calendar.SATURDAY -> 5
        java.util.Calendar.SUNDAY -> 6
        else -> 0
    }
    
    val maxDaysInCurrentMonth = cal.getActualMaximum(java.util.Calendar.DAY_OF_MONTH)
    
    val todayCal = java.util.Calendar.getInstance()
    val todayYear = todayCal.get(java.util.Calendar.YEAR)
    val todayMonth = todayCal.get(java.util.Calendar.MONTH) + 1
    val todayDay = todayCal.get(java.util.Calendar.DAY_OF_MONTH)
    
    if (prefixDaysCount > 0) {
        val prevMonthCal = java.util.Calendar.getInstance().apply {
            clear()
            set(java.util.Calendar.YEAR, year)
            set(java.util.Calendar.MONTH, month - 2)
        }
        val maxDaysInPrevMonth = prevMonthCal.getActualMaximum(java.util.Calendar.DAY_OF_MONTH)
        val startDay = maxDaysInPrevMonth - prefixDaysCount + 1
        for (d in startDay..maxDaysInPrevMonth) {
            prevMonthCal.set(java.util.Calendar.DAY_OF_MONTH, d)
            days.add(
                CalendarDay(
                    dayOfMonth = d,
                    isCurrentMonth = false,
                    timestamp = prevMonthCal.timeInMillis
                )
            )
        }
    }
    
    for (d in 1..maxDaysInCurrentMonth) {
        cal.set(java.util.Calendar.DAY_OF_MONTH, d)
        val isToday = (year == todayYear && month == todayMonth && d == todayDay)
        days.add(
            CalendarDay(
                dayOfMonth = d,
                isCurrentMonth = true,
                timestamp = cal.timeInMillis,
                isToday = isToday
            )
        )
    }
    
    val remainingCells = 42 - days.size
    if (remainingCells > 0) {
        val nextMonthCal = java.util.Calendar.getInstance().apply {
            clear()
            set(java.util.Calendar.YEAR, year)
            set(java.util.Calendar.MONTH, month)
        }
        for (d in 1..remainingCells) {
            nextMonthCal.set(java.util.Calendar.DAY_OF_MONTH, d)
            days.add(
                CalendarDay(
                    dayOfMonth = d,
                    isCurrentMonth = false,
                    timestamp = nextMonthCal.timeInMillis
                )
            )
        }
    }
    
    return days
}

@Composable
fun MonthlyCalendarView(
    viewModel: StudyViewModel,
    tasks: List<Task>,
    selectedDate: Long,
    onDateSelected: (Long) -> Unit
) {
    val calendar = java.util.Calendar.getInstance().apply { timeInMillis = selectedDate }
    var displayedMonth by remember { mutableStateOf(calendar.get(java.util.Calendar.MONTH) + 1) } // 1-indexed (Jan=1, Jun=6)
    var displayedYear by remember { mutableStateOf(calendar.get(java.util.Calendar.YEAR)) }

    val frenchMonths = listOf(
        "", "Janvier", "Février", "Mars", "Avril", "Mai", "Juin", 
        "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre"
    )

    val days = remember(displayedMonth, displayedYear) {
        getDaysInMonth(displayedYear, displayedMonth)
    }

    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
        modifier = Modifier
            .fillMaxWidth()
            .border(
                1.dp,
                MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f),
                RoundedCornerShape(24.dp)
            ),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = {
                        if (displayedMonth == 1) {
                            displayedMonth = 12
                            displayedYear -= 1
                        } else {
                            displayedMonth -= 1
                        }
                    },
                    modifier = Modifier
                        .size(36.dp)
                        .background(MaterialTheme.colorScheme.surfaceContainer, CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Mois précédent",
                        modifier = Modifier.size(20.dp)
                    )
                }

                Text(
                    text = "${frenchMonths[displayedMonth]} $displayedYear",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )

                IconButton(
                    onClick = {
                        if (displayedMonth == 12) {
                            displayedMonth = 1
                            displayedYear += 1
                        } else {
                            displayedMonth += 1
                        }
                    },
                    modifier = Modifier
                        .size(36.dp)
                        .background(MaterialTheme.colorScheme.surfaceContainer, CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowForward,
                        contentDescription = "Mois suivant",
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            val weekDays = listOf("Lun", "Mar", "Mer", "Jeu", "Ven", "Sam", "Dim")
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                weekDays.forEach { dayName ->
                    Text(
                        text = dayName,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.outline,
                        modifier = Modifier.weight(1f),
                        textAlign = TextAlign.Center
                    )
                }
            }

            AnimatedContent(
                targetState = displayedMonth to displayedYear,
                transitionSpec = {
                    if (targetState.second > initialState.second || (targetState.second == initialState.second && targetState.first > initialState.first)) {
                        (slideInHorizontally { width -> width } + fadeIn() togetherWith 
                         slideOutHorizontally { width -> -width } + fadeOut()).using(
                            SizeTransform(clip = false)
                        )
                    } else {
                        (slideInHorizontally { width -> -width } + fadeIn() togetherWith 
                         slideOutHorizontally { width -> width } + fadeOut()).using(
                            SizeTransform(clip = false)
                        )
                    }
                },
                label = "MonthTransition"
            ) { (targetMonth, targetYear) ->
                val activeDays = remember(targetMonth, targetYear) {
                    getDaysInMonth(targetYear, targetMonth)
                }
                Column(
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    for (row in 0 until 6) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            for (col in 0 until 7) {
                                val index = row * 7 + col
                                if (index < activeDays.size) {
                                    val day = activeDays[index]
                                    val isSelected = isSameDay(day.timestamp, selectedDate)
                                    val dayTasks = tasks.filter { isSameDay(it.timestamp, day.timestamp) }
                                    
                                    val scale by animateFloatAsState(
                                        targetValue = if (isSelected) 1.05f else 1.0f,
                                        animationSpec = spring(stiffness = Spring.StiffnessLow),
                                        label = "DayScale"
                                    )
                                    val backgroundColor by animateColorAsState(
                                        targetValue = when {
                                            isSelected -> MaterialTheme.colorScheme.primary
                                            day.isToday -> MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
                                            else -> Color.Transparent
                                        },
                                        animationSpec = tween(durationMillis = 200),
                                        label = "DayBg"
                                    )

                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .aspectRatio(1f)
                                            .scale(scale)
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(backgroundColor)
                                            .clickable {
                                                onDateSelected(day.timestamp)
                                            }
                                            .padding(4.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Column(
                                            horizontalAlignment = Alignment.CenterHorizontally,
                                            verticalArrangement = Arrangement.Center,
                                            modifier = Modifier.fillMaxSize()
                                        ) {
                                            Text(
                                                text = day.dayOfMonth.toString(),
                                                style = MaterialTheme.typography.bodyMedium,
                                                fontWeight = if (isSelected || day.isToday) FontWeight.Bold else FontWeight.Normal,
                                                color = when {
                                                    isSelected -> MaterialTheme.colorScheme.onPrimary
                                                    !day.isCurrentMonth -> MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)
                                                    day.isToday -> MaterialTheme.colorScheme.primary
                                                    else -> MaterialTheme.colorScheme.onSurface
                                                }
                                            )
                                            
                                            if (dayTasks.isNotEmpty() && day.isCurrentMonth) {
                                                Row(
                                                    horizontalArrangement = Arrangement.spacedBy(2.dp),
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    modifier = Modifier.padding(top = 2.dp)
                                                ) {
                                                    val uniquePriorities = dayTasks.map { it.priority }.distinct().take(3)
                                                    uniquePriorities.forEach { priority ->
                                                        val dotColor = when (priority) {
                                                            "Élevé" -> Color(0xFFD32F2F)
                                                            "Moyen" -> Color(0xFFF57C00)
                                                            else -> Color(0xFF1976D2)
                                                        }
                                                        Box(
                                                            modifier = Modifier
                                                                .size(5.dp)
                                                                .background(if (isSelected) Color.White else dotColor, CircleShape)
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }
                                } else {
                                    Box(modifier = Modifier.weight(1f).aspectRatio(1f))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

